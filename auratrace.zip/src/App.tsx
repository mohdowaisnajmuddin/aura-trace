import React, { useState, useEffect } from 'react';
import { Device, DeviceEvent, AlertRecord, UserSettings, AuthUser } from './types';
import { firestoreStore } from './services/firestoreService';
import { authService } from './services/authService';
import { Navbar } from './components/Navbar';
import { DeviceStatusCard } from './components/DeviceStatusCard';
import { EventFeed } from './components/EventFeed';
import { AlertSettingsPanel } from './components/AlertSettingsPanel';
import { FaqPage } from './components/FaqPage';
import { PrivacyModal } from './components/PrivacyModal';
import { DeviceEventSimulator } from './components/DeviceEventSimulator';
import { GoogleAuthModal } from './components/GoogleAuthModal';
import { LandingPage } from './components/LandingPage';
import { ShieldAlert, Info, ExternalLink, Radio, Bell, Shield } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'landing' | 'dashboard' | 'settings' | 'faq'>('landing');
  const [device, setDevice] = useState<Device | null>(null);
  const [events, setEvents] = useState<DeviceEvent[]>([]);
  const [alerts, setAlerts] = useState<AlertRecord[]>([]);
  const [settings, setSettings] = useState<UserSettings>(firestoreStore.getSettings());
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(authService.getCurrentUser());
  
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [isGoogleAuthOpen, setIsGoogleAuthOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'signin' | 'signup'>('signin');

  // Listen to Auth State
  useEffect(() => {
    const unsubAuth = authService.onAuthStateChanged((user) => {
      setCurrentUser(user);
      if (user && user.email) {
        // Sync user email with alert recipient if needed
        firestoreStore.updateSettings({ recipientEmail: user.email });
      }
    });
    return () => unsubAuth();
  }, []);

  // Firestore real-time onSnapshot listeners (PRD Section 3.4 & 4)
  useEffect(() => {
    const unsubDevice = firestoreStore.onSnapshotDevice('dev-pixel8-in', (updatedDevice) => {
      setDevice(updatedDevice);
    });

    const unsubEvents = firestoreStore.onSnapshotEvents('dev-pixel8-in', (updatedEvents) => {
      setEvents(updatedEvents);
    });

    const unsubAlerts = firestoreStore.onSnapshotAlerts('dev-pixel8-in', (updatedAlerts) => {
      setAlerts(updatedAlerts);
    });

    const unsubSettings = firestoreStore.onSnapshotSettings((updatedSettings) => {
      setSettings(updatedSettings);
    });

    return () => {
      unsubDevice();
      unsubEvents();
      unsubAlerts();
      unsubSettings();
    };
  }, []);

  if (!device) {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center p-4">
        <div className="text-zinc-400 text-sm font-medium">Initializing AuraTrace Firestore Listener...</div>
      </div>
    );
  }

  const handlePushEvent = (input: {
    type: 'sim_change' | 'location_jump' | 'ble_sighting' | 'heartbeat';
    payload: DeviceEvent['payload'];
  }) => {
    return firestoreStore.pushEvent(input);
  };

  const handleSaveSettings = (newSettings: Partial<UserSettings>) => {
    firestoreStore.updateSettings(newSettings);
  };

  const handleDeleteMyData = () => {
    return firestoreStore.deleteMyData();
  };

  const handleResetSampleData = () => {
    firestoreStore.resetSampleData();
  };

  const handleOpenGoogleAuth = (mode: 'signin' | 'signup' = 'signin') => {
    setAuthMode(mode);
    setIsGoogleAuthOpen(true);
  };

  const handleAuthSuccess = (user: AuthUser) => {
    setCurrentUser(user);
    // After signing in, transition to the live dashboard
    setCurrentTab('dashboard');
  };

  const handleSignOut = () => {
    authService.signOut();
  };

  // If on Landing Page, render the dedicated protective, calm dark landing experience
  if (currentTab === 'landing') {
    return (
      <>
        <LandingPage
          onViewLiveDemo={() => setCurrentTab('dashboard')}
          onOpenGoogleAuth={handleOpenGoogleAuth}
          onOpenPrivacyModal={() => setIsPrivacyOpen(true)}
          onOpenFaq={() => setCurrentTab('faq')}
          currentUser={currentUser}
          onSignOut={handleSignOut}
          device={device}
          events={events}
        />

        {/* Google Authentication Dialog */}
        <GoogleAuthModal
          isOpen={isGoogleAuthOpen}
          onClose={() => setIsGoogleAuthOpen(false)}
          onSuccess={handleAuthSuccess}
          initialMode={authMode}
        />

        {/* DPDP Act Privacy Modal */}
        <PrivacyModal
          isOpen={isPrivacyOpen}
          onClose={() => setIsPrivacyOpen(false)}
          onNavigateToSettings={() => {
            setIsPrivacyOpen(false);
            setCurrentTab('settings');
          }}
        />
      </>
    );
  }

  // Otherwise, render full application dashboard / settings / faq view in unified dark neutral theme
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-zinc-800 selection:text-white">
      {/* Navigation Bar */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        openPrivacyModal={() => setIsPrivacyOpen(true)}
        openSimulator={() => setIsSimulatorOpen(true)}
        openGoogleAuth={handleOpenGoogleAuth}
        currentUser={currentUser}
        onSignOut={handleSignOut}
        deviceStatus={device.status}
        alertsCount={alerts.length}
      />

      {/* Emergency Notification Banner for Confirmed High Risk */}
      {device.status === 'high_risk' && (
        <div 
          id="critical-alert-banner"
          className="bg-red-950/90 text-red-200 border-b border-red-800/80 px-4 py-2.5 text-xs font-medium flex items-center justify-between animate-in fade-in"
        >
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-red-400 shrink-0" />
              <span>
                <strong className="text-red-100">CRITICAL SECURITY ALERT:</strong> High risk probability ({device.riskScore}/100) detected on &quot;{device.nickname}&quot;. Multi-channel SMS & Email dispatch initiated.
              </span>
            </div>
            <button
              onClick={() => setCurrentTab('dashboard')}
              className="px-2.5 py-1 bg-red-900/60 hover:bg-red-800/60 rounded text-[11px] font-semibold text-red-100 border border-red-700/60 transition-colors shrink-0"
            >
              Inspect Diagnostics
            </button>
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {currentTab === 'dashboard' && (
          <div className="space-y-8">
            {/* Protective, Calm Centered Headline & Subhead */}
            <div className="text-center max-w-3xl mx-auto space-y-2 pt-2 pb-1">
              <h1 className="text-2xl sm:text-3xl font-medium tracking-tight text-zinc-100">
                Know the moment something changes
              </h1>
              <p className="text-sm text-zinc-400 max-w-2xl mx-auto">
                SIM-swap detection, location monitoring, and real-time security alerts for Android devices.
              </p>
            </div>

            {/* Short Three-Item Feature Row with plain unbadged icons */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 max-w-5xl mx-auto">
              <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl space-y-1 text-left">
                <div className="flex items-center gap-2 text-zinc-300 font-medium text-xs">
                  <Radio className="w-4 h-4 text-zinc-400 shrink-0" strokeWidth={1.75} />
                  <span>SIM-change detection</span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Listens to Android SubscriptionManager state transitions. Hashes subscription tokens with SHA-256 without extracting raw IMSI.
                </p>
              </div>

              <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl space-y-1 text-left">
                <div className="flex items-center gap-2 text-zinc-300 font-medium text-xs">
                  <Bell className="w-4 h-4 text-zinc-400 shrink-0" strokeWidth={1.75} />
                  <span>Real-time alerts</span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Triggers multi-channel SMS and email dispatch before a potential thief disconnects cellular networks or powers down the device.
                </p>
              </div>

              <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl space-y-1 text-left">
                <div className="flex items-center gap-2 text-zinc-300 font-medium text-xs">
                  <Shield className="w-4 h-4 text-zinc-400 shrink-0" strokeWidth={1.75} />
                  <span>Private by design</span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-relaxed">
                  Strictly compliant with India&apos;s DPDP Act 2023. Zero raw IMSI storage, 90-day auto-purge, and one-click data deletion.
                </p>
              </div>
            </div>

            {/* Scoped Hardware Claim Notice Banner (PRD Section 0 & 9) */}
            <div className="bg-zinc-900 border border-zinc-800/90 rounded-xl p-3.5 sm:p-4 text-xs text-zinc-400 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <Info className="w-4 h-4 text-zinc-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-medium text-zinc-200">Stock Android Hardware Scoping Notice: </span>
                  <span>
                    AuraTrace scopes SIM detection to stock Android 10+ subscription state transitions via salted SHA-256 digests. Raw IMSI is never requested or stored.
                  </span>
                </div>
              </div>
              <button
                onClick={() => setCurrentTab('faq')}
                className="text-zinc-200 font-medium underline underline-offset-2 flex items-center gap-1 shrink-0 self-start sm:self-auto hover:text-white"
              >
                <span>Read Verification Note</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Dashboard Layout: Single column mobile, two-column on desktop ≥900px (PRD Section 3.2) */}
            <div className="grid grid-cols-1 min-[900px]:grid-cols-12 gap-6 items-start">
              {/* Left Column: Device Status Card (5 cols on desktop ≥900px) */}
              <div className="min-[900px]:col-span-5 min-[900px]:sticky min-[900px]:top-24 space-y-4">
                <DeviceStatusCard 
                  device={device} 
                  onTriggerSimulate={() => setIsSimulatorOpen(true)} 
                />

                {/* Model Summary Attribution Card */}
                <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 text-xs text-zinc-400 space-y-2 text-left">
                  <div className="flex items-center justify-between">
                    <span className="font-medium text-zinc-200">Logistic Risk Engine</span>
                    <span className="font-mono text-[11px] text-emerald-400 bg-emerald-950/60 px-2 py-0.5 rounded border border-emerald-800/60">
                      94.2% Precision
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400">
                    Transparent mathematical scoring. Every risk point is attributed to explicit telemetry factors rather than opaque black-box outputs.
                  </p>
                </div>
              </div>

              {/* Right Column: Event Feed with Inline Detail Expansion (7 cols on desktop ≥900px) */}
              <div className="min-[900px]:col-span-7">
                <EventFeed 
                  events={events} 
                  alerts={alerts} 
                />
              </div>
            </div>
          </div>
        )}

        {currentTab === 'settings' && (
          <AlertSettingsPanel
            settings={settings}
            device={device}
            onSaveSettings={handleSaveSettings}
            onDeleteMyData={handleDeleteMyData}
            onResetSampleData={handleResetSampleData}
          />
        )}

        {currentTab === 'faq' && (
          <FaqPage
            onOpenPrivacyModal={() => setIsPrivacyOpen(true)}
            onNavigateToSettings={() => setCurrentTab('settings')}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-900 bg-zinc-950 py-6 mt-12 text-xs text-zinc-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div>
            <span className="font-medium text-zinc-300">AuraTrace</span> — Anti-Theft & Device Recovery System
            <span className="block sm:inline sm:ml-2 text-zinc-500">
              Compliant with India DPDP Act 2023
            </span>
          </div>
          <div className="flex items-center gap-4 text-zinc-400">
            <button
              onClick={() => setCurrentTab('landing')}
              className="hover:text-zinc-200 transition-colors"
            >
              Overview
            </button>
            <span>•</span>
            <button
              onClick={() => setIsPrivacyOpen(true)}
              className="hover:text-zinc-200 transition-colors underline underline-offset-2"
            >
              DPDP Privacy Policy
            </button>
            <span>•</span>
            <button
              onClick={() => setCurrentTab('faq')}
              className="hover:text-zinc-200 transition-colors"
            >
              Scoped Claims FAQ
            </button>
            <span>•</span>
            <button
              onClick={() => setIsSimulatorOpen(true)}
              className="hover:text-zinc-200 font-medium text-zinc-300"
            >
              Event Simulator
            </button>
          </div>
        </div>
      </footer>

      {/* Google Authentication Dialog */}
      <GoogleAuthModal
        isOpen={isGoogleAuthOpen}
        onClose={() => setIsGoogleAuthOpen(false)}
        onSuccess={handleAuthSuccess}
        initialMode={authMode}
      />

      {/* DPDP Act Privacy Modal */}
      <PrivacyModal
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
        onNavigateToSettings={() => {
          setIsPrivacyOpen(false);
          setCurrentTab('settings');
        }}
      />

      {/* Device Telemetry Push Simulator */}
      <DeviceEventSimulator
        isOpen={isSimulatorOpen}
        onClose={() => setIsSimulatorOpen(false)}
        onPushEvent={handlePushEvent}
      />
    </div>
  );
}
