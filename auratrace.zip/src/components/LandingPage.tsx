import React from 'react';
import { 
  Smartphone, 
  Cpu, 
  Bell, 
  Shield, 
  ArrowRight, 
  Lock, 
  CheckCircle,
  ExternalLink,
  MapPin,
  Clock,
  Radio
} from 'lucide-react';
import { AuthUser, Device, DeviceEvent } from '../types';

interface LandingPageProps {
  onViewLiveDemo: () => void;
  onOpenGoogleAuth: (mode?: 'signin' | 'signup') => void;
  onOpenPrivacyModal: () => void;
  onOpenFaq: () => void;
  currentUser: AuthUser | null;
  onSignOut: () => void;
  device: Device;
  events: DeviceEvent[];
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onViewLiveDemo,
  onOpenGoogleAuth,
  onOpenPrivacyModal,
  onOpenFaq,
  currentUser,
  onSignOut,
  device,
  events
}) => {
  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-200 selection:bg-zinc-800 selection:text-zinc-100 flex flex-col font-sans">
      {/* Top Navigation */}
      <header className="border-b border-zinc-900 bg-zinc-950/90 sticky top-0 z-30 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-300">
              <Smartphone className="w-4 h-4" strokeWidth={1.75} />
            </div>
            <div className="flex items-center gap-2">
              <span className="font-medium text-base text-zinc-100 tracking-tight">AuraTrace</span>
              <span className="text-[11px] font-mono text-zinc-500 border border-zinc-800 px-1.5 py-0.5 rounded">v2.0</span>
            </div>
          </div>

          <div className="flex items-center gap-4 text-xs">
            <button
              onClick={onOpenFaq}
              className="text-zinc-400 hover:text-zinc-200 transition-colors hidden sm:block"
            >
              Architecture & FAQ
            </button>
            <button
              onClick={onOpenPrivacyModal}
              className="text-zinc-400 hover:text-zinc-200 transition-colors hidden sm:block"
            >
              DPDP Privacy
            </button>

            {currentUser ? (
              <div className="flex items-center gap-2 pl-2 border-l border-zinc-800">
                <span className="text-zinc-400 hidden md:inline truncate max-w-[140px]">
                  {currentUser.displayName}
                </span>
                <button
                  onClick={onViewLiveDemo}
                  className="px-3 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-medium transition-colors"
                >
                  Dashboard
                </button>
                <button
                  onClick={onSignOut}
                  className="text-zinc-500 hover:text-zinc-300 transition-colors"
                  title="Sign out of Google"
                >
                  Sign out
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => onOpenGoogleAuth('signin')}
                  className="px-3 py-1.5 rounded-md text-zinc-300 hover:text-white hover:bg-zinc-900 transition-colors"
                >
                  Sign in with Google
                </button>
                <button
                  onClick={onViewLiveDemo}
                  className="px-3 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-white font-medium transition-colors"
                >
                  View live demo
                </button>
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-20 pb-16 sm:pt-28 sm:pb-20 px-4 sm:px-6 lg:px-8 text-center max-w-4xl mx-auto">
        {/* Core Value Headline */}
        <h1 className="text-3xl sm:text-5xl font-normal tracking-tight text-zinc-100 leading-tight">
          Know the moment something changes
        </h1>

        {/* Plain-Language Subhead */}
        <p className="mt-4 sm:mt-5 text-base sm:text-lg text-zinc-400 max-w-2xl mx-auto font-normal leading-relaxed">
          SIM-swap detection, location monitoring, and real-time security alerts for Android devices.
        </p>

        {/* Primary CTA & Secondary Action */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={onViewLiveDemo}
            className="w-full sm:w-auto px-6 py-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-medium transition-colors flex items-center justify-center gap-2"
          >
            <span>View live demo</span>
            <ArrowRight className="w-4 h-4" />
          </button>
          {!currentUser && (
            <button
              onClick={() => onOpenGoogleAuth('signin')}
              className="w-full sm:w-auto px-5 py-3 rounded-lg border border-zinc-800 bg-zinc-900/60 hover:bg-zinc-900 text-zinc-300 hover:text-white text-sm font-medium transition-colors flex items-center justify-center gap-2"
            >
              <span>Sign in with Google</span>
            </button>
          )}
        </div>

        <div className="mt-4 text-xs text-zinc-500">
          No credit card required. Scoped to Android 10+ SubscriptionManager telemetry.
        </div>
      </section>

      {/* Three-Item Feature Row (Strictly plain icons, no colored badges) */}
      <section className="py-12 border-y border-zinc-900 bg-zinc-900/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Feature 1: SIM-change detection */}
            <div className="space-y-3">
              <div className="text-zinc-400">
                <Cpu className="w-5 h-5" strokeWidth={1.5} />
              </div>
              <h3 className="text-sm font-medium text-zinc-100 tracking-tight">
                SIM-change detection
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Tracks cryptographic SHA-256 hashes of Subscription ID transitions. Immediately flags when a physical SIM or eSIM profile is removed or altered.
              </p>
            </div>

            {/* Feature 2: Real-time alerts */}
            <div className="space-y-3">
              <div className="text-zinc-400">
                <Bell className="w-5 h-5" strokeWidth={1.5} />
              </div>
              <h3 className="text-sm font-medium text-zinc-100 tracking-tight">
                Real-time alerts
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Evaluates risk with a logistic scoring engine and dispatches emergency SMS and incident email alerts before an adversary can power down or disconnect the device.
              </p>
            </div>

            {/* Feature 3: Private by design */}
            <div className="space-y-3">
              <div className="text-zinc-400">
                <Shield className="w-5 h-5" strokeWidth={1.5} />
              </div>
              <h3 className="text-sm font-medium text-zinc-100 tracking-tight">
                Private by design
              </h3>
              <p className="text-xs text-zinc-400 leading-relaxed">
                Complies with India&apos;s DPDP Act 2023. Raw IMSI is never read or stored. Includes guaranteed 90-day retention limits and one-click data deletion.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Below the fold: Single realistic mockup of the actual dashboard */}
      <section className="py-16 sm:py-24 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto w-full">
        <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
          <h2 className="text-xl sm:text-2xl font-normal text-zinc-100 tracking-tight">
            The actual product, not a rendered concept
          </h2>
          <p className="text-xs sm:text-sm text-zinc-400">
            A single unified view showing current device state, computed risk score, and real-time telemetry events.
          </p>
        </div>

        {/* Dashboard Realistic Frame */}
        <div className="rounded-xl border border-zinc-800 bg-zinc-900/60 shadow-2xl overflow-hidden">
          {/* Mockup Titlebar */}
          <div className="bg-zinc-900 px-4 py-3 border-b border-zinc-800 flex items-center justify-between text-xs text-zinc-400">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-zinc-700" />
              <span className="w-2.5 h-2.5 rounded-full bg-zinc-700" />
              <span className="w-2.5 h-2.5 rounded-full bg-zinc-700" />
              <span className="ml-2 font-mono text-[11px] text-zinc-400">
                auratrace.internal/monitor/{device.id}
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              <span className="text-zinc-300 text-[11px]">Live Sync Active</span>
            </div>
          </div>

          {/* Actual Dashboard Preview Body */}
          <div className="p-4 sm:p-6 lg:p-8 bg-zinc-950/70">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
              {/* Left Column: Device Status Card Mockup */}
              <div className="md:col-span-5 bg-zinc-900 border border-zinc-800 rounded-xl p-5 space-y-5 text-left">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[11px] font-mono text-zinc-400 uppercase tracking-wider block">
                      Protected Hardware
                    </span>
                    <h3 className="text-base font-medium text-white tracking-tight mt-0.5">
                      {device.nickname}
                    </h3>
                    <p className="text-xs text-zinc-400">{device.deviceModel}</p>
                  </div>
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    Secure
                  </span>
                </div>

                {/* Risk Metric Box (Numeric, not a dial) */}
                <div className="bg-zinc-950 border border-zinc-800/80 rounded-lg p-3.5 flex items-center justify-between">
                  <div>
                    <span className="text-xs text-zinc-400 block">Computed Risk Probability</span>
                    <span className="text-2xl font-mono text-zinc-100 tracking-tight font-medium">
                      {device.riskScore}
                      <span className="text-xs text-zinc-500 font-sans ml-1">/ 100</span>
                    </span>
                  </div>
                  <div className="text-right text-[11px] text-zinc-400">
                    <div>Warning: 35</div>
                    <div>Critical: 70</div>
                  </div>
                </div>

                {/* Telemetry rows */}
                <div className="space-y-2.5 text-xs">
                  <div className="flex items-center justify-between py-1.5 border-b border-zinc-800/60">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-zinc-500" />
                      Last Check-In
                    </span>
                    <span className="text-zinc-200 font-mono text-[11px]">3 mins ago</span>
                  </div>

                  <div className="flex items-center justify-between py-1.5 border-b border-zinc-800/60">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <Radio className="w-3.5 h-3.5 text-zinc-500" />
                      Carrier Network
                    </span>
                    <span className="text-zinc-200 text-[11px]">Jio True5G (SA)</span>
                  </div>

                  <div className="flex items-center justify-between py-1.5 border-b border-zinc-800/60">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-zinc-500" />
                      Last Location
                    </span>
                    <span className="text-zinc-200 text-[11px] truncate max-w-[180px]">
                      BKC, Mumbai, India
                    </span>
                  </div>

                  <div className="flex items-center justify-between py-1.5">
                    <span className="text-zinc-400 flex items-center gap-1.5">
                      <Shield className="w-3.5 h-3.5 text-zinc-500" />
                      Scoped SIM Hash
                    </span>
                    <span className="text-zinc-400 font-mono text-[10px]">
                      {device.lastKnownSimHash.slice(0, 14)}...
                    </span>
                  </div>
                </div>
              </div>

              {/* Right Column: Recent Events Feed Mockup */}
              <div className="md:col-span-7 space-y-3 text-left">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-zinc-300">
                    Recent Telemetry Events ({events.length})
                  </span>
                  <span className="text-[11px] text-zinc-500">Real-time reactive feed</span>
                </div>

                <div className="space-y-2.5">
                  {events.slice(0, 3).map((evt) => (
                    <div
                      key={evt.id}
                      className="bg-zinc-900 border border-zinc-800 rounded-lg p-3.5 space-y-1.5"
                    >
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-medium text-zinc-200">
                            {evt.type === 'heartbeat' ? 'Heartbeat & BLE Check-in' : evt.type}
                          </span>
                          <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-400">
                            Risk {evt.riskScore}
                          </span>
                        </div>
                        <span className="text-zinc-500 text-[11px]">Just now</span>
                      </div>

                      <p className="text-xs text-zinc-400">
                        {evt.payload.location?.addressSummary || 'Telemetry corroborated by paired wearable.'}
                      </p>

                      {evt.triggeredFactors.length > 0 && (
                        <div className="text-[11px] text-emerald-400 bg-emerald-950/40 border border-emerald-900/40 px-2 py-1 rounded">
                          {evt.triggeredFactors[0].label}: {evt.triggeredFactors[0].impactScore} impact
                        </div>
                      )}
                    </div>
                  ))}
                </div>

                <div className="pt-2">
                  <button
                    onClick={onViewLiveDemo}
                    className="w-full py-2.5 rounded-lg border border-zinc-800 hover:border-zinc-700 bg-zinc-900 hover:bg-zinc-850 text-xs font-medium text-zinc-200 hover:text-white transition-all flex items-center justify-center gap-1.5"
                  >
                    <span>Launch interactive live monitor with event simulation</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Security & Scoped Claims Section */}
      <section className="py-14 border-t border-zinc-900 bg-zinc-950">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="text-left space-y-2">
            <h3 className="text-base font-medium text-zinc-100 tracking-tight">
              Stock Android hardware reality, explained plainly
            </h3>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Third-party security apps cannot read raw hardware IMSI or ICCID values on Android 10+ without privileged carrier signatures (<code className="text-zinc-300 font-mono">READ_PRIVILEGED_PHONE_STATE</code>). AuraTrace complies with this platform boundary by computing salted SHA-256 digests of <code className="text-zinc-300 font-mono">SubscriptionManager</code> state transitions. You receive immediate tamper alerts without permitting invasive operating system snooping.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-zinc-400 pt-2">
            <div className="p-3.5 rounded-lg border border-zinc-900 bg-zinc-900/40 space-y-1">
              <div className="font-medium text-zinc-200 flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                <span>Statutory DPDP Erasure</span>
              </div>
              <p className="text-[11px] text-zinc-400">
                You can delete your device history and account records irreversibly at any time directly from the settings panel.
              </p>
            </div>
            <div className="p-3.5 rounded-lg border border-zinc-900 bg-zinc-900/40 space-y-1">
              <div className="font-medium text-zinc-200 flex items-center gap-1.5">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-500" />
                <span>Multi-Channel Out-of-Band Alerts</span>
              </div>
              <p className="text-[11px] text-zinc-400">
                Configurable threshold triggers deliver notifications via SMS and email before network connectivity is severed.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-zinc-900 py-8 text-xs text-zinc-500">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-medium text-zinc-300">AuraTrace</span>
            <span>—</span>
            <span>Device recovery and anti-theft monitoring system</span>
          </div>

          <div className="flex items-center gap-5 text-zinc-400">
            <button
              onClick={onOpenPrivacyModal}
              className="hover:text-zinc-200 transition-colors"
            >
              Privacy Policy
            </button>
            <button
              onClick={onOpenFaq}
              className="hover:text-zinc-200 transition-colors"
            >
              Hardware Scoping
            </button>
            <button
              onClick={onViewLiveDemo}
              className="hover:text-zinc-200 transition-colors"
            >
              Live Demo
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
};
