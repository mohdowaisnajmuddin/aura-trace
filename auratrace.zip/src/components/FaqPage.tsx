import React, { useState } from 'react';
import { 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Radio, 
  Clock, 
  Lock, 
  Cpu, 
  Trash2,
  ExternalLink,
  FileText
} from 'lucide-react';
import { RISK_MODEL_METADATA } from '../services/riskEngine';

interface FaqPageProps {
  onOpenPrivacyModal: () => void;
  onNavigateToSettings: () => void;
}

export const FaqPage: React.FC<FaqPageProps> = ({ onOpenPrivacyModal, onNavigateToSettings }) => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleAccordion = (index: number) => {
    setOpenIndex((prev) => (prev === index ? null : index));
  };

  const faqItems = [
    {
      id: 'faq-sim-detection',
      icon: <Radio className="w-4 h-4 text-zinc-300" />,
      question: 'What exactly does AuraTrace detect regarding SIM and IMSI changes?',
      shortAnswer: 'Stock Android 10+ restricts raw IMSI/ICCID access to carrier apps. AuraTrace detects subscription ID state transitions via salted hashes rather than claiming impossible raw IMSI extraction.',
      fullAnswer: (
        <div className="space-y-3 text-xs text-zinc-300 leading-relaxed">
          <div className="p-3 bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-200">
            <span className="font-medium text-zinc-100 block mb-1">Stock Android Hardware Scoping Notice:</span>
            On non-rooted, stock Android 10 (API 29) through Android 15+, Google strictly restricts the `TelephonyManager.getSubscriberId()` (raw IMSI) and `getSimSerialNumber()` (ICCID) APIs. Third-party applications cannot read these identifiers without carrier or platform-signed system privileges.
          </div>
          <p>
            Rather than overstating capabilities, <strong>AuraTrace accurately scopes SIM detection</strong> to what stock consumer hardware actually allows:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-zinc-400">
            <li>
              <strong className="text-zinc-200">Subscription Change Events:</strong> Listens to `SubscriptionManager.OnSubscriptionsChangedListener` and `TelephonyCallback` broadcast triggers when a physical SIM tray is ejected or an eSIM profile is swapped.
            </li>
            <li>
              <strong className="text-zinc-200">Salted Subscription Hashes:</strong> Computes a salted SHA-256 hash of the active SubscriptionId, Carrier ID, and network MCC/MNC. If an unauthorized SIM swap occurs, the hash immediately diverges from the device’s registered baseline.
            </li>
            <li>
              <strong className="text-zinc-200">Zero Plaintext Storage:</strong> Raw IMSI is never requested, logged, or stored at any tier of the AuraTrace infrastructure.
            </li>
          </ul>
        </div>
      )
    },
    {
      id: 'faq-alert-speed',
      icon: <Clock className="w-4 h-4 text-zinc-300" />,
      question: 'How fast are alerts delivered when a theft or SIM swap is detected?',
      shortAnswer: 'Typical delivery takes between 45 seconds to 3 minutes due to mobile OS battery management (Doze mode) and carrier SMS dispatch queues.',
      fullAnswer: (
        <div className="space-y-2 text-xs text-zinc-300 leading-relaxed">
          <p>
            We state the real latency floor plainly: <strong>alerts are not instantaneous 0-second notifications</strong>. Modern Android devices enforce aggressive battery optimization and Doze mode cycles.
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-zinc-400">
            <li>
              <strong className="text-zinc-200">Foreground / Active State:</strong> If a SIM is hot-swapped while the device is awake, the Android OS triggers the subscription listener within ~3–5 seconds, pushes telemetry to our `/api/events` Cloud endpoint within ~10 seconds, and Twilio/SendGrid dispatches alerts within ~30–45 seconds.
            </li>
            <li>
              <strong className="text-zinc-200">Deep Doze / Sleep State:</strong> If the phone has been idle, the OS may batch background network jobs using `WorkManager` or expedited high-priority FCM pulses, introducing a realistic 2 to 3 minute latency window.
            </li>
            <li>
              <strong className="text-zinc-200">Airplane Mode / Faraday Bag:</strong> If a thief immediately powers off the device or disconnects cellular/Wi-Fi, telemetry cannot leave the device until connectivity is re-established. The backend flags an &quot;Unexplained Telemetry Blackout&quot; after 18 hours of silence.
            </li>
          </ul>
        </div>
      )
    },
    {
      id: 'faq-location-retention',
      icon: <Lock className="w-4 h-4 text-zinc-300" />,
      question: 'What happens to my location data? What is the retention policy?',
      shortAnswer: 'Location telemetry is collected solely for anomaly detection, retained for a strictly enforced 90-day window, and never sold to third-party data brokers.',
      fullAnswer: (
        <div className="space-y-2 text-xs text-zinc-300 leading-relaxed">
          <p>
            Under India&apos;s Digital Personal Data Protection (DPDP) Act 2023, GPS breadcrumbs constitute sensitive personal data. We adhere to data minimization principles:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-zinc-400">
            <li>
              <strong className="text-zinc-200">Purpose Limitation:</strong> GPS coordinates are processed exclusively by our logistic risk model to measure distance deltas and velocity anomalies (e.g. detecting sudden 500+ km movements).
            </li>
            <li>
              <strong className="text-zinc-200">Strict 90-Day Auto-Purge:</strong> Any telemetry record older than 90 days is automatically scrubbed from Firestore via scheduled TTL lifecycle rules.
            </li>
            <li>
              <strong className="text-zinc-200">Named Processors:</strong> We only transmit notification data to Twilio Inc. (SMS delivery) and SendGrid / Twilio (email delivery) when alerting you. No location data is shared with advertisers or third-party SDKs.
            </li>
          </ul>
          <div className="pt-2">
            <button
              onClick={onOpenPrivacyModal}
              className="text-xs font-medium text-zinc-200 underline underline-offset-2 flex items-center gap-1 hover:text-white"
            >
              <span>Read Full DPDP Privacy Disclosure</span>
              <ExternalLink className="w-3 h-3" />
            </button>
          </div>
        </div>
      )
    },
    {
      id: 'faq-delete-data',
      icon: <Trash2 className="w-4 h-4 text-zinc-300" />,
      question: 'Can I delete all my stored data at any time?',
      shortAnswer: 'Yes. AuraTrace includes an explicit, one-click &quot;Delete My Data&quot; control in Settings that immediately purges your device registration, location history, and alert logs.',
      fullAnswer: (
        <div className="space-y-2 text-xs text-zinc-300 leading-relaxed">
          <p>
            In compliance with statutory user erasure rights, you do not need to submit a support ticket or wait 30 days.
          </p>
          <p className="text-zinc-400">
            Navigating to the <strong>Settings</strong> tab reveals the <strong>DPDP Data Erasure</strong> section. Confirming the deletion instantly executes a recursive delete across <code>devices/&#123;deviceId&#125;</code>, <code>events/&#123;eventId&#125;</code>, and <code>alerts/&#123;alertId&#125;</code> in Firestore, along with client-side local cache clearing.
          </p>
          <div className="pt-1">
            <button
              onClick={onNavigateToSettings}
              className="text-xs font-medium text-zinc-200 underline underline-offset-2 flex items-center gap-1 hover:text-white"
            >
              <span>Go to Settings to view deletion control</span>
            </button>
          </div>
        </div>
      )
    },
    {
      id: 'faq-ble-network',
      icon: <Cpu className="w-4 h-4 text-zinc-300" />,
      question: 'Is the community BLE offline-finding network active?',
      shortAnswer: 'The community crowdsourced mesh is scoped to protocol specification with HMAC-based rotating UUIDs. It is marked protocol-only until multi-device hardware verification is complete.',
      fullAnswer: (
        <div className="space-y-2 text-xs text-zinc-300 leading-relaxed">
          <p>
            Per the PRD Scope and Milestone Order, <strong>we do not claim a fully deployed community BLE mesh network</strong> without empirical multi-device validation.
          </p>
          <p className="text-zinc-400">
            What is currently implemented and validated:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-zinc-400">
            <li>
              <strong className="text-zinc-200">Personal Companion Proximity:</strong> AuraTrace detects registered companion wearables (e.g. Pixel Watch, personal BLE beacon) using HMAC-authenticated rotating tokens to prevent replay attacks and tracking.
            </li>
            <li>
              <strong className="text-zinc-200">False Positive Suppression:</strong> If a SIM event or sudden relocation happens in the confirmed presence of the owner&apos;s companion BLE tag, the risk score is automatically discounted (-22 points) to avoid false theft panic.
            </li>
            <li>
              <strong className="text-zinc-200">Crowdsourced Mesh:</strong> Full multi-phone mesh relay remains on the product backlog pending large-scale density testing.
            </li>
          </ul>
        </div>
      )
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6 text-left">
      {/* Header */}
      <div>
        <h1 className="text-xl font-medium text-zinc-100 tracking-tight">Frequently Asked Questions & Scoped Claims</h1>
        <p className="text-sm text-zinc-400 mt-0.5">
          Engineering transparency regarding hardware limitations, real latency floors, and DPDP compliance.
        </p>
      </div>

      {/* Accordion List */}
      <div className="space-y-3">
        {faqItems.map((item, index) => {
          const isOpen = openIndex === index;
          return (
            <div
              key={item.id}
              id={item.id}
              className="bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-sm transition-all"
            >
              <button
                onClick={() => toggleAccordion(index)}
                className="w-full p-4 sm:p-5 flex items-start justify-between gap-4 text-left hover:bg-zinc-850/60 transition-colors"
                aria-expanded={isOpen}
              >
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-lg bg-zinc-950 border border-zinc-800 flex items-center justify-center shrink-0 mt-0.5">
                    {item.icon}
                  </div>
                  <div>
                    <h3 className="text-sm font-medium text-zinc-200 leading-snug">
                      {item.question}
                    </h3>
                    <p className="text-xs text-zinc-400 mt-1 line-clamp-2">
                      {item.shortAnswer}
                    </p>
                  </div>
                </div>

                <div className="text-zinc-400 shrink-0 mt-1">
                  {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </div>
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-2 border-t border-zinc-800/80 animate-in fade-in duration-150">
                  {item.fullAnswer}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* ML Pipeline Transparency Card (PRD Section 6) */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center gap-2.5 pb-3 border-b border-zinc-800/80">
          <FileText className="w-4 h-4 text-zinc-300" strokeWidth={1.75} />
          <h2 className="text-sm font-medium text-zinc-100">Machine Learning Pipeline & Model Metadata</h2>
        </div>

        <div className="mt-4 space-y-3 text-xs text-zinc-300">
          <div className="p-3 bg-zinc-950 rounded-lg border border-zinc-800 text-zinc-300">
            <span className="font-medium text-zinc-100 block mb-1">Dataset & Methodology Disclosure:</span>
            {RISK_MODEL_METADATA.datasetNote}
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
            <div className="p-2.5 bg-zinc-950 rounded-lg border border-zinc-800">
              <span className="text-[11px] text-zinc-400 block">Model Architecture</span>
              <span className="font-medium text-zinc-200 text-xs">Logistic Regression</span>
            </div>
            <div className="p-2.5 bg-zinc-950 rounded-lg border border-zinc-800">
              <span className="text-[11px] text-zinc-400 block">Evaluation Precision</span>
              <span className="font-medium text-emerald-400 text-xs">{(RISK_MODEL_METADATA.precision * 100).toFixed(1)}%</span>
            </div>
            <div className="p-2.5 bg-zinc-950 rounded-lg border border-zinc-800">
              <span className="text-[11px] text-zinc-400 block">Evaluation Recall</span>
              <span className="font-medium text-emerald-400 text-xs">{(RISK_MODEL_METADATA.recall * 100).toFixed(1)}%</span>
            </div>
            <div className="p-2.5 bg-zinc-950 rounded-lg border border-zinc-800">
              <span className="text-[11px] text-zinc-400 block">Sample Scenarios</span>
              <span className="font-mono text-zinc-200 text-xs">{RISK_MODEL_METADATA.sampleSize.toLocaleString()}</span>
            </div>
          </div>

          <div className="pt-2">
            <span className="font-medium text-zinc-200 block mb-1.5">Scored Feature Vector Weights:</span>
            <div className="flex flex-wrap gap-1.5">
              {RISK_MODEL_METADATA.features.map((feature, i) => (
                <span key={i} className="font-mono text-[11px] bg-zinc-950 text-zinc-300 px-2 py-1 rounded border border-zinc-800">
                  {feature}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
