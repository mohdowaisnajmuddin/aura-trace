import React, { useState } from 'react';
import { 
  Settings, 
  Trash2, 
  MessageSquare, 
  Mail, 
  ShieldAlert, 
  Check, 
  AlertTriangle, 
  Clock, 
  Lock, 
  RotateCcw,
  Smartphone
} from 'lucide-react';
import { UserSettings, Device } from '../types';

interface AlertSettingsPanelProps {
  settings: UserSettings;
  device: Device;
  onSaveSettings: (newSettings: Partial<UserSettings>) => void;
  onDeleteMyData: () => { success: boolean; purgedRecords: number };
  onResetSampleData: () => void;
}

export const AlertSettingsPanel: React.FC<AlertSettingsPanelProps> = ({
  settings,
  device,
  onSaveSettings,
  onDeleteMyData,
  onResetSampleData
}) => {
  const [formState, setFormState] = useState<UserSettings>({ ...settings });
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [deleteNotification, setDeleteNotification] = useState<{ message: string; count: number } | null>(null);

  const handleToggleSms = () => {
    setFormState((prev) => ({ ...prev, smsAlertsEnabled: !prev.smsAlertsEnabled }));
  };

  const handleToggleEmail = () => {
    setFormState((prev) => ({ ...prev, emailAlertsEnabled: !prev.emailAlertsEnabled }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveSettings(formState);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const executeDeleteMyData = () => {
    setIsDeleting(true);
    setTimeout(() => {
      const result = onDeleteMyData();
      setIsDeleting(false);
      setDeleteConfirmOpen(false);
      setDeleteNotification({
        message: 'All device location logs, SIM hashes, and security telemetry have been permanently purged.',
        count: result.purgedRecords
      });
    }, 400);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 text-left">
      {/* Page Title */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-medium text-zinc-100 tracking-tight">System & Alert Preferences</h1>
          <p className="text-sm text-zinc-400 mt-0.5">
            Configure multi-channel notification routing, anomaly thresholds, and DPDP data rights.
          </p>
        </div>
        <button
          onClick={onResetSampleData}
          className="text-xs font-medium text-zinc-300 hover:text-white flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-zinc-800 bg-zinc-900 hover:bg-zinc-850 transition-colors"
          title="Restore realistic demo baseline"
        >
          <RotateCcw className="w-3.5 h-3.5 text-zinc-400" />
          <span>Reset Demo Data</span>
        </button>
      </div>

      {deleteNotification && (
        <div className="p-4 bg-zinc-900 border border-zinc-800 text-zinc-200 rounded-xl text-xs flex items-center justify-between animate-in fade-in">
          <div>
            <span className="font-semibold text-emerald-400 mr-2">✓ Purge Complete:</span>
            <span>{deleteNotification.message} ({deleteNotification.count} records scrubbed)</span>
          </div>
          <button 
            onClick={() => setDeleteNotification(null)}
            className="text-zinc-400 hover:text-white ml-3 underline"
          >
            Dismiss
          </button>
        </div>
      )}

      {saveSuccess && (
        <div className="p-3.5 bg-emerald-950/60 border border-emerald-800/60 text-emerald-400 rounded-xl text-xs flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>Preferences updated and synchronized to Firestore configuration.</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Section 1: Device Nickname & Registration */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center gap-2.5 pb-3 border-b border-zinc-800/80">
            <Smartphone className="w-4 h-4 text-zinc-300" strokeWidth={1.75} />
            <h2 className="text-sm font-medium text-zinc-100">Device Identity</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 text-xs">
            <div>
              <label className="block text-zinc-300 font-medium mb-1.5">
                Device Nickname
              </label>
              <input
                type="text"
                id="input-device-nickname"
                value={formState.deviceNickname}
                onChange={(e) => setFormState({ ...formState, deviceNickname: e.target.value })}
                className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-sm text-zinc-100 focus:outline-none focus:border-zinc-700"
                placeholder="e.g. Pixel 8 Daily"
                required
              />
              <p className="text-[11px] text-zinc-400 mt-1">
                Name shown in outgoing SMS and email alerts.
              </p>
            </div>

            <div>
              <label className="block text-zinc-300 font-medium mb-1.5">
                Device Model & OS
              </label>
              <div className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-sm text-zinc-400 font-mono">
                {device.deviceModel} • {device.osVersion}
              </div>
              <p className="text-[11px] text-zinc-400 mt-1">
                Detected via mobile background client handshake.
              </p>
            </div>
          </div>
        </div>

        {/* Section 2: Alert Channels (SMS & Email) */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center gap-2.5 pb-3 border-b border-zinc-800/80">
            <MessageSquare className="w-4 h-4 text-zinc-300" strokeWidth={1.75} />
            <h2 className="text-sm font-medium text-zinc-100">Multi-Channel Alert Routing</h2>
          </div>

          <div className="space-y-4 mt-4">
            {/* SMS Channel */}
            <div className="p-4 rounded-lg border border-zinc-800/80 bg-zinc-950 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1 max-w-md">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-zinc-200 text-sm">SMS Emergency Alerts</span>
                  <span className="text-[10px] font-mono bg-zinc-900 border border-zinc-800 px-1.5 py-0.5 rounded text-zinc-400">Twilio Webhook</span>
                </div>
                <p className="text-xs text-zinc-400">
                  Sends an immediate SMS dispatch when risk score crosses warning or critical thresholds.
                </p>
                <div className="pt-2">
                  <input
                    type="tel"
                    id="input-recipient-phone"
                    value={formState.recipientPhone}
                    onChange={(e) => setFormState({ ...formState, recipientPhone: e.target.value })}
                    className="w-full max-w-xs px-3 py-1.5 text-xs border border-zinc-800 rounded-md bg-zinc-900 text-zinc-100 focus:outline-none focus:border-zinc-700"
                    placeholder="+91 98765 43210"
                  />
                </div>
              </div>

              <button
                type="button"
                id="toggle-sms-alert"
                onClick={handleToggleSms}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  formState.smsAlertsEnabled ? 'bg-emerald-600' : 'bg-zinc-800'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    formState.smsAlertsEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>

            {/* Email Channel */}
            <div className="p-4 rounded-lg border border-zinc-800/80 bg-zinc-950 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div className="space-y-1 max-w-md">
                <div className="flex items-center gap-2">
                  <span className="font-medium text-zinc-200 text-sm">Email Incident Reports</span>
                  <span className="text-[10px] font-mono bg-zinc-900 border border-zinc-800 px-1.5 py-0.5 rounded text-zinc-400">SendGrid SMTP</span>
                </div>
                <p className="text-xs text-zinc-400">
                  Sends full telemetry diagnostic reports with location maps and factor attribution.
                </p>
                <div className="pt-2">
                  <input
                    type="email"
                    id="input-recipient-email"
                    value={formState.recipientEmail}
                    onChange={(e) => setFormState({ ...formState, recipientEmail: e.target.value })}
                    className="w-full max-w-xs px-3 py-1.5 text-xs border border-zinc-800 rounded-md bg-zinc-900 text-zinc-100 focus:outline-none focus:border-zinc-700"
                    placeholder="owner@example.com"
                  />
                </div>
              </div>

              <button
                type="button"
                id="toggle-email-alert"
                onClick={handleToggleEmail}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  formState.emailAlertsEnabled ? 'bg-emerald-600' : 'bg-zinc-800'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    formState.emailAlertsEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>
        </div>

        {/* Section 3: Risk Thresholds & Rate Limiting (PRD Section 8) */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-sm">
          <div className="flex items-center gap-2.5 pb-3 border-b border-zinc-800/80">
            <ShieldAlert className="w-4 h-4 text-zinc-300" strokeWidth={1.75} />
            <h2 className="text-sm font-medium text-zinc-100">Risk Thresholds & Rate-Limiting</h2>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 text-xs">
            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-zinc-300 font-medium">Warning Threshold (Amber)</label>
                <span className="font-mono text-zinc-200 font-medium">{formState.warningThreshold} / 100</span>
              </div>
              <input
                type="range"
                min={20}
                max={50}
                value={formState.warningThreshold}
                onChange={(e) => setFormState({ ...formState, warningThreshold: parseInt(e.target.value) })}
                className="w-full accent-emerald-500"
              />
              <p className="text-[11px] text-zinc-400 mt-1">
                Score level triggering elevated-risk monitoring and email report.
              </p>
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="text-zinc-300 font-medium">Critical Alert Threshold (Red)</label>
                <span className="font-mono text-zinc-200 font-medium">{formState.criticalThreshold} / 100</span>
              </div>
              <input
                type="range"
                min={55}
                max={85}
                value={formState.criticalThreshold}
                onChange={(e) => setFormState({ ...formState, criticalThreshold: parseInt(e.target.value) })}
                className="w-full accent-emerald-500"
              />
              <p className="text-[11px] text-zinc-400 mt-1">
                Score level triggering immediate emergency SMS alert dispatch.
              </p>
            </div>

            <div>
              <label className="block text-zinc-300 font-medium mb-1.5">
                Rate-Limit Quiet Window (Minutes)
              </label>
              <input
                type="number"
                min={5}
                max={60}
                value={formState.rateLimitMinutes}
                onChange={(e) => setFormState({ ...formState, rateLimitMinutes: parseInt(e.target.value) || 15 })}
                className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-sm text-zinc-100 focus:outline-none focus:border-zinc-700 font-mono"
              />
              <p className="text-[11px] text-zinc-400 mt-1">
                Prevents alert-spam loops during erratic cellular network handovers.
              </p>
            </div>

            <div>
              <label className="block text-zinc-300 font-medium mb-1.5">
                Telemetry Retention Window (DPDP)
              </label>
              <div className="w-full px-3 py-2 bg-zinc-950 border border-zinc-800 rounded-lg text-sm text-zinc-300 font-mono">
                {formState.dataRetentionDays} Days (Compliant with India DPDP Act)
              </div>
              <p className="text-[11px] text-zinc-400 mt-1">
                Historical GPS breadcrumbs auto-purge after 90 days.
              </p>
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-zinc-800 flex justify-end">
            <button
              type="submit"
              id="btn-save-settings"
              className="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-sm font-medium transition-colors"
            >
              Save Alert Preferences
            </button>
          </div>
        </div>
      </form>

      {/* Section 4: One-Click "Delete My Data" (PRD Section 3.4 & 7) */}
      <div id="section-delete-data" className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-sm">
        <div className="flex items-center gap-2.5 pb-3 border-b border-zinc-800/80">
          <Trash2 className="w-4 h-4 text-red-400" strokeWidth={1.75} />
          <h2 className="text-sm font-medium text-zinc-100">DPDP Data Erasure (Right to Erasure)</h2>
        </div>

        <div className="mt-3 text-xs text-zinc-400 space-y-2">
          <p>
            Under India&apos;s Digital Personal Data Protection (DPDP) Act 2023, you have the absolute statutory right to demand full erasure of your telemetry records.
          </p>
          <p className="text-zinc-400">
            Clicking this will permanently delete all stored GPS coordinates, movement breadcrumbs, SIM hash signatures, and incident alert records from the database.
          </p>
        </div>

        <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-1.5 text-xs text-zinc-400">
            <Lock className="w-3.5 h-3.5 text-zinc-400" />
            <span>Immediate cryptographic purge of all records</span>
          </div>

          {!deleteConfirmOpen ? (
            <button
              type="button"
              id="btn-open-delete-modal"
              onClick={() => setDeleteConfirmOpen(true)}
              className="px-3.5 py-1.5 rounded-lg text-xs font-medium bg-red-950/60 text-red-400 hover:bg-red-900/60 border border-red-800/60 transition-colors flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Delete My Data</span>
            </button>
          ) : (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setDeleteConfirmOpen(false)}
                className="px-3 py-1.5 rounded-lg text-xs font-medium text-zinc-400 hover:text-zinc-200 border border-zinc-800 transition-colors"
              >
                Cancel
              </button>
              <button
                type="button"
                id="btn-confirm-delete"
                onClick={executeDeleteMyData}
                disabled={isDeleting}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium bg-red-600 hover:bg-red-500 text-white transition-colors flex items-center gap-1.5"
              >
                {isDeleting ? 'Purging...' : 'Confirm Purge (Permanent)'}
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
