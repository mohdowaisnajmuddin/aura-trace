import React, { useState } from 'react';
import { 
  Bell, 
  ChevronDown, 
  ChevronUp, 
  MapPin, 
  Radio, 
  ShieldAlert, 
  ShieldCheck, 
  AlertTriangle, 
  Activity, 
  Clock, 
  Mail, 
  MessageSquare,
  Cpu
} from 'lucide-react';
import { DeviceEvent, AlertRecord } from '../types';

interface EventFeedProps {
  events: DeviceEvent[];
  alerts: AlertRecord[];
  onSelectEvent?: (event: DeviceEvent) => void;
}

export const EventFeed: React.FC<EventFeedProps> = ({ events, alerts }) => {
  // Inline expansion tracking (PRD 3.4: "expanding inline rather than navigating away, to keep context")
  const [expandedEventId, setExpandedEventId] = useState<string | null>(events[0]?.id || null);
  const [filterMode, setFilterMode] = useState<'all' | 'alerts_only'>('all');

  const toggleExpand = (id: string) => {
    setExpandedEventId((prev) => (prev === id ? null : id));
  };

  const getEventIcon = (type: DeviceEvent['type'], score: number) => {
    if (score >= 70) {
      return <ShieldAlert className="w-4 h-4 text-red-400" strokeWidth={1.75} />;
    }
    if (score >= 30) {
      return <AlertTriangle className="w-4 h-4 text-amber-400" strokeWidth={1.75} />;
    }
    switch (type) {
      case 'sim_change':
        return <Radio className="w-4 h-4 text-zinc-400" strokeWidth={1.75} />;
      case 'location_jump':
        return <MapPin className="w-4 h-4 text-zinc-400" strokeWidth={1.75} />;
      case 'ble_sighting':
        return <Cpu className="w-4 h-4 text-zinc-400" strokeWidth={1.75} />;
      case 'heartbeat':
      default:
        return <Activity className="w-4 h-4 text-zinc-400" strokeWidth={1.75} />;
    }
  };

  const getScoreBadge = (score: number) => {
    if (score >= 70) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-mono font-medium bg-red-950/60 text-red-400 border border-red-800/60">
          Risk {score}
        </span>
      );
    }
    if (score >= 30) {
      return (
        <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-mono font-medium bg-amber-950/60 text-amber-400 border border-amber-800/60">
          Risk {score}
        </span>
      );
    }
    return (
      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-mono font-medium bg-zinc-800/80 text-zinc-300 border border-zinc-700/60">
        Score {score}
      </span>
    );
  };

  const getEventTitle = (event: DeviceEvent) => {
    switch (event.type) {
      case 'sim_change':
        return 'SIM Subscription State Mutation';
      case 'location_jump':
        return `Location Anomaly (${event.payload.distanceDeltaKm ? `${Math.round(event.payload.distanceDeltaKm)} km jump` : 'Relocated'})`;
      case 'ble_sighting':
        return 'BLE Companion Device Telemetry';
      case 'heartbeat':
        return 'Scheduled Telemetry Heartbeat';
      default:
        return 'Device Telemetry Event';
    }
  };

  const filteredEvents = events.filter((evt) => {
    if (filterMode === 'alerts_only') {
      return evt.riskScore >= 30 || evt.alertDispatched !== undefined;
    }
    return true;
  });

  return (
    <div id="event-feed-container" className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-sm text-left">
      {/* Header & Filter Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-zinc-800/80">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-zinc-950 border border-zinc-800 flex items-center justify-center text-zinc-300">
            <Bell className="w-4 h-4" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-base font-medium text-zinc-100 leading-snug tracking-tight">
              Recent Telemetry & Event Feed
            </h2>
            <p className="text-xs text-zinc-400">
              Live updates via Firestore listeners • No polling required
            </p>
          </div>
        </div>

        {/* Filter Toggle */}
        <div className="flex items-center bg-zinc-950 p-1 rounded-lg border border-zinc-800 text-xs self-start sm:self-auto">
          <button
            onClick={() => setFilterMode('all')}
            className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
              filterMode === 'all'
                ? 'bg-zinc-800 text-zinc-100 shadow-xs'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            All Events ({events.length})
          </button>
          <button
            onClick={() => setFilterMode('alerts_only')}
            className={`px-2.5 py-1 rounded-md font-medium transition-colors flex items-center gap-1.5 ${
              filterMode === 'alerts_only'
                ? 'bg-zinc-800 text-zinc-100 shadow-xs'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <span>Flagged</span>
            <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          </button>
        </div>
      </div>

      {/* Events List */}
      <div className="divide-y divide-zinc-800/70 mt-2">
        {filteredEvents.length === 0 ? (
          <div className="py-12 text-center">
            <div className="w-10 h-10 rounded-full bg-zinc-950 border border-zinc-800 flex items-center justify-center text-zinc-400 mx-auto mb-2">
              <ShieldCheck className="w-5 h-5 text-emerald-400" strokeWidth={1.75} />
            </div>
            <p className="text-sm font-medium text-zinc-200">No elevated risk events detected</p>
            <p className="text-xs text-zinc-400 mt-1 max-w-sm mx-auto">
              Device telemetry remains inside baseline thresholds. Any SIM swap or location jump will appear here in real time.
            </p>
          </div>
        ) : (
          filteredEvents.map((event) => {
            const isExpanded = expandedEventId === event.id;
            const associatedAlerts = alerts.filter((a) => a.eventId === event.id);

            return (
              <div 
                key={event.id}
                id={`event-row-${event.id}`}
                className="py-3 transition-colors"
              >
                {/* Event Summary Row (Clickable inline toggle) */}
                <div
                  onClick={() => toggleExpand(event.id)}
                  className="flex items-center justify-between gap-3 cursor-pointer group hover:bg-zinc-850/50 p-2 rounded-lg -mx-2 transition-colors"
                  role="button"
                  tabIndex={0}
                  aria-expanded={isExpanded}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div className="w-8 h-8 rounded-lg bg-zinc-950 border border-zinc-800 flex items-center justify-center shrink-0 group-hover:border-zinc-700">
                      {getEventIcon(event.type, event.riskScore)}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-zinc-200 truncate">
                          {getEventTitle(event)}
                        </span>
                        {getScoreBadge(event.riskScore)}
                      </div>
                      <p className="text-xs text-zinc-400 truncate mt-0.5">
                        {event.payload.location?.addressSummary || 'BKC, Mumbai • 5G SA'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs text-zinc-400 font-mono hidden sm:inline">
                      {new Date(event.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <div className="text-zinc-400 group-hover:text-zinc-200">
                      {isExpanded ? (
                        <ChevronUp className="w-4 h-4" />
                      ) : (
                        <ChevronDown className="w-4 h-4" />
                      )}
                    </div>
                  </div>
                </div>

                {/* Expanded Inline Detail (PRD Section 3.1 & 3.4) */}
                {isExpanded && (
                  <div className="mt-3 pl-3 sm:pl-11 pr-2 space-y-3 text-xs animate-in fade-in duration-150">
                    {/* Timestamp & Event ID */}
                    <div className="flex flex-wrap items-center justify-between gap-2 p-2.5 bg-zinc-950 border border-zinc-800/80 rounded-lg text-zinc-400">
                      <div className="flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5 text-zinc-400" />
                        <span className="font-mono text-[11px] text-zinc-300">
                          {new Date(event.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <div className="font-mono text-[11px] text-zinc-400">
                        Event ID: {event.id}
                      </div>
                    </div>

                    {/* Trigger Factors Breakdown (PRD Section 6) */}
                    <div className="p-3 bg-zinc-950 border border-zinc-800/80 rounded-lg">
                      <div className="text-xs font-medium text-zinc-300 mb-2 flex items-center justify-between">
                        <span>Risk Scoring Model Attribution</span>
                        <span className="text-[11px] text-zinc-400 font-mono">Logistic Regression Weights</span>
                      </div>

                      {event.triggeredFactors.length > 0 ? (
                        <div className="space-y-2">
                          {event.triggeredFactors.map((factor, idx) => (
                            <div 
                              key={idx}
                              className="p-2.5 bg-zinc-900 rounded border border-zinc-800 flex items-start justify-between gap-3"
                            >
                              <div>
                                <div className="font-medium text-zinc-200 text-xs">
                                  {factor.label}
                                </div>
                                <div className="text-zinc-400 text-[11px] mt-0.5">
                                  {factor.description}
                                </div>
                              </div>
                              <span 
                                className={`font-mono text-xs font-medium shrink-0 ${
                                  factor.impactScore > 0 ? 'text-red-400' : 'text-emerald-400'
                                }`}
                              >
                                {factor.impactScore > 0 ? `+${factor.impactScore}` : factor.impactScore} pts
                              </span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-zinc-400 text-[11px]">
                          Normal operating telemetry. Baseline probability within safe margins.
                        </div>
                      )}
                    </div>

                    {/* Specific Telemetry Payload Context */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
                      {/* Location context */}
                      {event.payload.location && (
                        <div className="p-2.5 bg-zinc-950 border border-zinc-800/80 rounded-lg">
                          <div className="text-zinc-400 font-medium mb-1 flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-zinc-400" />
                            <span>GPS Telemetry</span>
                          </div>
                          <div className="font-medium text-zinc-200">
                            {event.payload.location.addressSummary}
                          </div>
                          <div className="font-mono text-zinc-400 mt-0.5">
                            {event.payload.location.latitude.toFixed(5)}, {event.payload.location.longitude.toFixed(5)}
                          </div>
                          {event.payload.distanceDeltaKm !== undefined && (
                            <div className="mt-1 text-zinc-300 font-mono">
                              Delta: {event.payload.distanceDeltaKm} km in {event.payload.timeDeltaMinutes ?? 30} mins
                            </div>
                          )}
                        </div>
                      )}

                      {/* SIM or Hardware Context */}
                      {event.payload.simHash && (
                        <div className="p-2.5 bg-zinc-950 border border-zinc-800/80 rounded-lg">
                          <div className="text-zinc-400 font-medium mb-1 flex items-center gap-1">
                            <Radio className="w-3 h-3 text-zinc-400" />
                            <span>SIM Subscription Salted Hash</span>
                          </div>
                          <div className="font-mono text-[10px] text-zinc-300 break-all bg-zinc-900 p-1.5 rounded border border-zinc-800">
                            {event.payload.simHash}
                          </div>
                          {event.payload.simStateChangeReason && (
                            <div className="text-amber-400 mt-1 font-medium">
                              Trigger: {event.payload.simStateChangeReason}
                            </div>
                          )}
                        </div>
                      )}
                    </div>

                    {/* Dispatched Multi-Channel Alerts info if triggered */}
                    {associatedAlerts.length > 0 && (
                      <div className="p-3 bg-zinc-950 border border-red-900/60 rounded-lg text-xs">
                        <div className="font-medium text-red-400 mb-1.5 flex items-center gap-1.5">
                          <Bell className="w-3.5 h-3.5 text-red-400" />
                          <span>Dispatched Multi-Channel Notifications</span>
                        </div>
                        <div className="space-y-1.5">
                          {associatedAlerts.map((alert) => (
                            <div key={alert.id} className="flex items-center justify-between text-[11px] bg-zinc-900 p-2 rounded border border-zinc-800">
                              <div className="flex items-center gap-2">
                                {alert.channel === 'sms' ? (
                                  <MessageSquare className="w-3.5 h-3.5 text-zinc-400" />
                                ) : (
                                  <Mail className="w-3.5 h-3.5 text-zinc-400" />
                                )}
                                <span className="font-medium uppercase text-zinc-300">{alert.channel}</span>
                                <span className="text-zinc-400">→ {alert.recipient}</span>
                              </div>
                              <span className="font-mono text-emerald-400 font-medium capitalize">
                                {alert.deliveryStatus}
                              </span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
