import React, { useState } from 'react';
import { X, Shield, ArrowRight } from 'lucide-react';
import { authService } from '../services/authService';
import { AuthUser } from '../types';

interface GoogleAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: AuthUser) => void;
  initialMode?: 'signin' | 'signup';
}

export const GoogleAuthModal: React.FC<GoogleAuthModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  initialMode = 'signin'
}) => {
  const [mode, setMode] = useState<'signin' | 'signup'>(initialMode);
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  if (!isOpen) return null;

  const handleSignInWithEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) return;
    setIsLoading(true);
    try {
      await new Promise(r => setTimeout(r, 400));
      const user = await authService.signInWithGoogle({
        email: email.trim()
      });
      onSuccess(user);
      onClose();
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickDemoSignIn = async () => {
    setIsLoading(true);
    try {
      await new Promise(r => setTimeout(r, 400));
      const user = await authService.signInWithGoogle({
        email: 'demo@auratrace.org',
        name: 'Demo Account'
      });
      onSuccess(user);
      onClose();
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-150"
      onClick={onClose}
    >
      <div 
        className="bg-zinc-900 border border-zinc-800 text-zinc-100 rounded-2xl w-full max-w-md p-6 sm:p-7 shadow-2xl space-y-6"
        onClick={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            {/* Google G Logo */}
            <div className="w-10 h-10 rounded-xl bg-zinc-800 border border-zinc-700/60 flex items-center justify-center shrink-0">
              <svg className="w-5 h-5" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.65v3.03h3.88c2.27-2.09 3.665-5.17 3.665-9.12z"
                />
                <path
                  fill="#34A853"
                  d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.03c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.13C3.27 21.42 7.35 24 12 24z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.28 14.29c-.25-.72-.38-1.49-.38-2.29s.13-1.57.38-2.29V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.13z"
                />
                <path
                  fill="#EA4335"
                  d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.27 2.58 1.25 6.58l4.03 3.13c.95-2.83 3.6-4.96 6.72-4.96z"
                />
              </svg>
            </div>
            <div>
              <h3 className="text-base font-medium text-white tracking-tight">
                {mode === 'signin' ? 'Sign in with Google' : 'Sign up with Google'}
              </h3>
              <p className="text-xs text-zinc-400">
                to access your AuraTrace security monitor
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-200 transition-colors p-1 -mr-1 rounded-lg hover:bg-zinc-800"
            aria-label="Close dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Google Authentication Form */}
        <div className="space-y-4">
          <form onSubmit={handleSignInWithEmail} className="space-y-3.5">
            <div className="space-y-1.5 text-left">
              <label htmlFor="google-email" className="block text-xs font-medium text-zinc-300">
                Email or phone
              </label>
              <input
                id="google-email"
                type="email"
                required
                placeholder="Enter your Google email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-700 focus:border-zinc-500 text-zinc-100 rounded-xl px-3.5 py-2.5 text-xs focus:outline-none transition-colors placeholder:text-zinc-500"
                autoFocus
              />
            </div>

            <button
              type="submit"
              disabled={isLoading || !email.trim()}
              className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-medium transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-sm"
            >
              {isLoading ? (
                <span>Connecting...</span>
              ) : (
                <>
                  <span>Continue with Google</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <div className="relative flex items-center justify-center my-3">
            <div className="border-t border-zinc-800 w-full" />
            <span className="bg-zinc-900 px-2 text-[10px] text-zinc-500 uppercase tracking-wider shrink-0">or</span>
            <div className="border-t border-zinc-800 w-full" />
          </div>

          <button
            type="button"
            onClick={handleQuickDemoSignIn}
            disabled={isLoading}
            className="w-full py-2.5 px-3 text-xs text-zinc-300 hover:text-white hover:bg-zinc-800/60 rounded-xl transition-colors text-center border border-zinc-800 flex items-center justify-center gap-2"
          >
            <span>Continue with Demo Account (Instant Access)</span>
          </button>
        </div>

        {/* Security / Scoped Verification Note */}
        <div className="bg-zinc-950/60 border border-zinc-800/80 rounded-xl p-3 text-[11px] text-zinc-400 space-y-1.5">
          <div className="flex items-center gap-1.5 text-zinc-300 font-medium">
            <Shield className="w-3.5 h-3.5 text-emerald-500" />
            <span>Zero-Access Privacy Guarantee</span>
          </div>
          <p className="leading-relaxed">
            Authentication is used solely to link your registered Android device telemetry and dispatch verified alerts. We never read your contacts, files, or raw IMSI.
          </p>
        </div>

        {/* Toggle Mode */}
        <div className="pt-1 flex items-center justify-between text-xs text-zinc-400 border-t border-zinc-800/60">
          <span>
            {mode === 'signin' ? "Don't have an account yet?" : 'Already have an account?'}
          </span>
          <button
            type="button"
            onClick={() => setMode(mode === 'signin' ? 'signup' : 'signin')}
            className="text-zinc-300 hover:text-white underline underline-offset-2 transition-colors font-medium"
          >
            {mode === 'signin' ? 'Sign up with Google' : 'Sign in with Google'}
          </button>
        </div>
      </div>
    </div>
  );
};
