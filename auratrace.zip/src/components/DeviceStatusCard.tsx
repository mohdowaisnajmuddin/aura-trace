import React from 'react';
import { Smartphone, ShieldCheck, AlertTriangle, MapPin, Radio, Clock, ShieldAlert, Cpu, Info } from 'lucide-react';
import { Device, DeviceStatus } from '../types';

interface DeviceStatusCardProps {
  device: Device;
  onTriggerSimulate?: () => void;
}

export const DeviceStatusCard: React.FC<DeviceStatusCardProps> = ({ device, onTriggerSimulate }) => {
  // Format relative check-in time
  const formatTimeAgo = (isoString: string): string => {
    try {
      const diffMs = Date.now() - new Date(isoString).getTime();
      const diffSec = Math.floor(diffMs / 1000);
      if (diffSec < 45) return 'Just now';
      const diffMin = Math.floor(diffSec / 60);
      if (diffMin < 60) return `${diffMin}m ago`;
      const diffHr = Math.floor(diffMin / 60);
      if (diffHr < 24) return `${diffHr}h ago`;
      return new Date(isoString).toLocaleDateString();
    } catch {
      return 'Unknown';
    }
  };

  // Semantic status badge styling strictly adhering to protective, calm aesthetic
  const getStatusBadge = (status: DeviceStatus) => {
    switch (status) {
      case 'secure':
        return (
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-emerald-950/60 text-emerald-400 border border-emerald-800/60">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" strokeWidth={1.75} />
            <span>Secure</span>
          </div>
        );
      case 'elevated_risk':
        return (
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-amber-950/60 text-amber-400 border border-amber-800/60">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" strokeWidth={1.75} />
            <span>Elevated Risk</span>
          </div>
        );
      case 'high_risk':
        return (
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium bg-red-950/60 text-red-400 border border-red-800/60">
            <ShieldAlert className="w-3.5 h-3.5 text-red-400" strokeWidth={1.75} />
            <span>Confirmed High Risk</span>
          </div>
        );
    }
  };

  // Status color for the risk score metric card
  const getRiskScoreColorClass = (score: number) => {
    if (score >= 70) return 'text-red-400';
    if (score >= 30) return 'text-amber-400';
    return 'text-zinc-100';
  };

  return (
    <div id="device-status-card" className="bg-zinc-900 border border-zinc-800 rounded-xl p-5 shadow-sm text-left">
      {/* Header Row: Device Identity & Status Badge */}
      <div className="flex items-start justify-between gap-4 pb-4 border-b border-zinc-800/80">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-zinc-950 border border-zinc-800 flex items-center justify-center text-zinc-300 shrink-0">
            <Smartphone className="w-5 h-5" strokeWidth={1.75} />
          </div>
          <div>
            <h2 className="text-base font-medium text-zinc-100 leading-snug tracking-tight">
              {device.nickname}
            </h2>
            <p className="text-xs text-zinc-400 flex items-center gap-1.5 mt-0.5">
              <span>{device.deviceModel}</span>
              <span>•</span>
              <span className="font-mono text-zinc-400">{device.osVersion}</span>
            </p>
          </div>
        </div>

        {/* Semantic Status Badge */}
        <div>
          {getStatusBadge(device.status)}
        </div>
      </div>

      {/* Metrics Row: Risk Score + Check-in Time */}
      <div className="grid grid-cols-2 gap-3 my-4">
        {/* Risk Score Presentation: Plain number in metric card per PRD 3.3 (NO gauge or dial) */}
        <div id="metric-risk-score" className="bg-zinc-950 border border-zinc-800/80 rounded-lg p-3.5">
          <div className="flex items-center justify-between text-xs text-zinc-400 font-normal">
            <span>Risk Score</span>
            <span className="text-[11px] text-zinc-400 font-mono">0–100</span>
          </div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span className={`text-3xl font-medium tracking-tight font-mono ${getRiskScoreColorClass(device.riskScore)}`}>
              {device.riskScore}
            </span>
            <span className="text-xs text-zinc-400 font-mono">/ 100</span>
          </div>
          <p className="text-[11px] text-zinc-400 mt-1">
            {device.riskScore >= 70
              ? 'Multi-channel critical alert triggered'
              : device.riskScore >= 30
              ? 'Elevated probability of SIM or location anomaly'
              : 'Within expected baseline parameters'}
          </p>
        </div>

        {/* Last Check-in Metric */}
        <div id="metric-last-checkin" className="bg-zinc-950 border border-zinc-800/80 rounded-lg p-3.5">
          <div className="flex items-center gap-1.5 text-xs text-zinc-400 font-normal">
            <Clock className="w-3.5 h-3.5 text-zinc-400" strokeWidth={1.75} />
            <span>Last Telemetry</span>
          </div>
          <div className="mt-1 flex items-baseline">
            <span className="text-xl font-medium text-zinc-100">
              {formatTimeAgo(device.lastCheckIn)}
            </span>
          </div>
          <p className="text-[11px] text-zinc-400 mt-1.5 font-mono truncate" title={new Date(device.lastCheckIn).toLocaleString()}>
            {new Date(device.lastCheckIn).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </p>
        </div>
      </div>

      {/* Detailed Telemetry Attributes (SIM & Location) */}
      <div className="space-y-3 pt-1 text-xs">
        {/* SIM Hardware Status (Accurately scoped claim per PRD Section 0) */}
        <div className="p-3.5 bg-zinc-950 border border-zinc-800/80 rounded-lg space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-normal text-zinc-300 flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-zinc-400" strokeWidth={1.75} />
              SIM Subscription State
            </span>
            <span className="font-mono text-[11px] text-zinc-400 bg-zinc-900 px-1.5 py-0.5 rounded border border-zinc-800">
              Android 10+ Scoped
            </span>
          </div>
          <div className="text-zinc-300 font-mono text-[11px] break-all bg-zinc-900 p-2.5 rounded border border-zinc-800">
            <div className="text-zinc-400 text-[10px] uppercase tracking-wider mb-0.5">Salted SHA-256 Digest</div>
            {device.lastKnownSimHash.slice(0, 32)}...
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-zinc-400">
            <Info className="w-3.5 h-3.5 text-zinc-400 shrink-0" />
            <span>Raw IMSI is never read or stored. Scoped to subscription change broadcasts.</span>
          </div>
        </div>

        {/* Location Telemetry */}
        <div className="p-3.5 bg-zinc-950 border border-zinc-800/80 rounded-lg space-y-1">
          <div className="flex items-center justify-between text-zinc-300 font-normal">
            <span className="flex items-center gap-1.5">
              <MapPin className="w-3.5 h-3.5 text-zinc-400" strokeWidth={1.75} />
              Last Known Verified Location
            </span>
            <span className="text-[11px] text-zinc-400 font-mono">±{device.lastKnownLocation.accuracyMeters}m</span>
          </div>
          <p className="mt-1 font-medium text-zinc-200 text-xs">
            {device.lastKnownLocation.addressSummary}
          </p>
          <p className="font-mono text-[11px] text-zinc-400">
            {device.lastKnownLocation.latitude.toFixed(4)}° N, {device.lastKnownLocation.longitude.toFixed(4)}° E
          </p>
        </div>
      </div>

      {/* Action Footer */}
      {onTriggerSimulate && (
        <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-between">
          <span className="text-xs text-zinc-400">Testing pipeline response?</span>
          <button
            onClick={onTriggerSimulate}
            className="text-xs font-medium text-zinc-300 hover:text-white underline underline-offset-2 transition-colors"
          >
            Push synthetic telemetry
          </button>
        </div>
      )}
    </div>
  );
};
