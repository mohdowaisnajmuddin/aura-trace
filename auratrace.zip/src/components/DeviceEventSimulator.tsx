import React, { useState } from 'react';
import { X, Play, Radio, MapPin, Activity, ShieldAlert, Cpu } from 'lucide-react';
import { DeviceEvent } from '../types';

interface DeviceEventSimulatorProps {
  isOpen: boolean;
  onClose: () => void;
  onPushEvent: (input: {
    type: 'sim_change' | 'location_jump' | 'ble_sighting' | 'heartbeat';
    payload: DeviceEvent['payload'];
  }) => { event: DeviceEvent; riskScore: number; status: string };
}

export const DeviceEventSimulator: React.FC<DeviceEventSimulatorProps> = ({
  isOpen,
  onClose,
  onPushEvent
}) => {
  const [activeScenario, setActiveScenario] = useState<string | null>(null);
  const [lastExecutionResult, setLastExecutionResult] = useState<{
    eventName: string;
    riskScore: number;
    status: string;
  } | null>(null);

  if (!isOpen) return null;

  const runScenario = (
    name: string,
    type: 'sim_change' | 'location_jump' | 'ble_sighting' | 'heartbeat',
    payload: DeviceEvent['payload']
  ) => {
    setActiveScenario(name);
    const result = onPushEvent({ type, payload });
    setLastExecutionResult({
      eventName: name,
      riskScore: result.riskScore,
      status: result.status
    });
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div 
        className="bg-zinc-900 border border-zinc-800 rounded-xl max-w-xl w-full p-6 shadow-2xl relative text-left animate-in fade-in zoom-in-95 duration-150"
        role="dialog"
        aria-labelledby="simulator-modal-title"
      >
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-zinc-950 border border-zinc-800 flex items-center justify-center text-zinc-300">
              <Activity className="w-5 h-5" strokeWidth={1.75} />
            </div>
            <div>
              <h2 id="simulator-modal-title" className="text-base font-medium text-zinc-100 tracking-tight">
                Device Telemetry Simulator
              </h2>
              <p className="text-xs text-zinc-400">
                Simulates mobile push events via `POST /api/events` to verify the risk engine & listeners.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Execution Feedback */}
        {lastExecutionResult && (
          <div className="my-4 p-3.5 rounded-lg border border-zinc-800 bg-zinc-950 flex items-center justify-between text-xs">
            <div>
              <span className="font-medium text-zinc-200">{lastExecutionResult.eventName}</span>
              <div className="text-zinc-400 mt-0.5">
                Evaluated Risk Score: <strong className="font-mono text-zinc-100">{lastExecutionResult.riskScore} / 100</strong>
              </div>
            </div>
            <div className="text-right">
              <span 
                className={`inline-flex px-2 py-0.5 rounded text-[11px] font-medium font-mono uppercase tracking-wider ${
                  lastExecutionResult.status === 'high_risk'
                    ? 'bg-red-950/60 text-red-400 border border-red-800/60'
                    : lastExecutionResult.status === 'elevated_risk'
                    ? 'bg-amber-950/60 text-amber-400 border border-amber-800/60'
                    : 'bg-emerald-950/60 text-emerald-400 border border-emerald-800/60'
                }`}
              >
                {lastExecutionResult.status.replace('_', ' ')}
              </span>
            </div>
          </div>
        )}

        {/* Scenario List */}
        <div className="space-y-2.5 my-4 max-h-[60vh] overflow-y-auto pr-1">
          {/* Scenario 1: Unauthorized SIM Swap */}
          <div 
            onClick={() => runScenario(
              'Unauthorized SIM Swap Detected',
              'sim_change',
              {
                simHash: 'a89c00127ebff84192bc78012e8419f8012a9c4501928bc1209384bbfa817290',
                previousSimHash: 'f4b29a88c3e45990234a991c28b5e903d6118b958c89ff0234ac2b0123ef89aa',
                simStateChangeReason: 'SIM Tray Ejected & Unknown SIM Inserted',
                networkType: '4G LTE (Vi)',
                carrierName: 'Vodafone Idea',
                bleCorroborated: false,
                location: {
                  latitude: 19.0820,
                  longitude: 72.8810,
                  accuracyMeters: 22,
                  addressSummary: 'Kurla Station Road, Mumbai, India'
                }
              }
            )}
            className="p-3 border border-zinc-800/90 rounded-lg hover:border-zinc-700 bg-zinc-950 hover:bg-zinc-850/60 transition-colors cursor-pointer group flex items-start justify-between gap-3"
          >
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-amber-950/40 text-amber-400 border border-amber-800/50 flex items-center justify-center shrink-0 mt-0.5">
                <Radio className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-medium text-zinc-200 group-hover:text-white">
                  Scenario A: SIM Card Swap Detected
                </h4>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  Simulates physical SIM tray ejection on stock Android. Salted hash diverges from baseline.
                </p>
                <div className="mt-1 text-[10px] font-mono text-amber-400">
                  Expected Impact: +48 pts • Triggers Warning/SMS Alert
                </div>
              </div>
            </div>
            <Play className="w-4 h-4 text-zinc-400 group-hover:text-zinc-200 shrink-0 mt-2" />
          </div>

          {/* Scenario 2: Impossible Location Jump */}
          <div 
            onClick={() => runScenario(
              'Impossible Location Jump (Mumbai → Bengaluru)',
              'location_jump',
              {
                distanceDeltaKm: 840,
                timeDeltaMinutes: 22,
                location: {
                  latitude: 12.9716,
                  longitude: 77.5946,
                  accuracyMeters: 30,
                  addressSummary: 'MG Road, Bengaluru, Karnataka, India'
                },
                bleCorroborated: false
              }
            )}
            className="p-3 border border-zinc-800/90 rounded-lg hover:border-zinc-700 bg-zinc-950 hover:bg-zinc-850/60 transition-colors cursor-pointer group flex items-start justify-between gap-3"
          >
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-zinc-900 text-zinc-300 border border-zinc-800 flex items-center justify-center shrink-0 mt-0.5">
                <MapPin className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-medium text-zinc-200 group-hover:text-white">
                  Scenario B: Impossible Location Jump
                </h4>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  Device reports 840 km displacement in 22 minutes (~2,290 km/h anomaly exceeding physical travel).
                </p>
                <div className="mt-1 text-[10px] font-mono text-zinc-400">
                  Expected Impact: +34 pts • Evaluates Velocity Anomaly
                </div>
              </div>
            </div>
            <Play className="w-4 h-4 text-zinc-400 group-hover:text-zinc-200 shrink-0 mt-2" />
          </div>

          {/* Scenario 3: SIM Swap + Nighttime Relocation (High Risk) */}
          <div 
            onClick={() => {
              runScenario(
                'High Risk: SIM Swap + 3:42 AM Relocation',
                'sim_change',
                {
                  simHash: '9988ff00112233445566778899aabbccddeeff00112233445566778899aabbcc',
                  simStateChangeReason: 'eSIM profile revoked & physical SIM changed at night',
                  distanceDeltaKm: 380,
                  timeDeltaMinutes: 45,
                  networkType: '3G Fallback',
                  carrierName: 'Unknown Roaming',
                  bleCorroborated: false,
                  location: {
                    latitude: 20.0120,
                    longitude: 73.7910,
                    accuracyMeters: 45,
                    addressSummary: 'Highway Corridor, Nashik, India'
                  }
                }
              );
            }}
            className="p-3 border border-red-900/60 rounded-lg hover:border-red-800 bg-zinc-950 hover:bg-zinc-850/60 transition-colors cursor-pointer group flex items-start justify-between gap-3"
          >
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-red-950/50 text-red-400 border border-red-800/60 flex items-center justify-center shrink-0 mt-0.5">
                <ShieldAlert className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-medium text-red-300 group-hover:text-red-200">
                  Scenario C: High-Risk Compound Theft Event
                </h4>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  SIM swap + 380 km relocation during dormant hours (3:42 AM) without companion beacon.
                </p>
                <div className="mt-1 text-[10px] font-mono text-red-400">
                  Expected Score: 85+ • Triggers Critical SMS & Email Alert
                </div>
              </div>
            </div>
            <Play className="w-4 h-4 text-zinc-400 group-hover:text-red-400 shrink-0 mt-2" />
          </div>

          {/* Scenario 4: Legitimate Owner Swap (Mitigated by BLE) */}
          <div 
            onClick={() => runScenario(
              'Legitimate SIM Swap (Owner BLE Present)',
              'sim_change',
              {
                simHash: '11223344556677889900aabbccddeeff11223344556677889900aabbccddeeff',
                simStateChangeReason: 'Owner swapped to travel SIM',
                bleCorroborated: true,
                bleBeaconId: 'aura_hmac_owner_smartwatch',
                distanceDeltaKm: 2,
                timeDeltaMinutes: 10,
                location: {
                  latitude: 19.0760,
                  longitude: 72.8777,
                  accuracyMeters: 12,
                  addressSummary: 'Bandra Kurla Complex, Mumbai, India'
                }
              }
            )}
            className="p-3 border border-zinc-800/90 rounded-lg hover:border-zinc-700 bg-zinc-950 hover:bg-zinc-850/60 transition-colors cursor-pointer group flex items-start justify-between gap-3"
          >
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-emerald-950/40 text-emerald-400 border border-emerald-800/50 flex items-center justify-center shrink-0 mt-0.5">
                <Cpu className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-medium text-zinc-200 group-hover:text-white">
                  Scenario D: Legitimate Swap with BLE Corroboration
                </h4>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  SIM changed, but paired owner smartwatch was sighted. Proximity mitigation applies (-22 pts).
                </p>
                <div className="mt-1 text-[10px] font-mono text-emerald-400">
                  Optimized against False Positives
                </div>
              </div>
            </div>
            <Play className="w-4 h-4 text-zinc-400 group-hover:text-zinc-200 shrink-0 mt-2" />
          </div>

          {/* Scenario 5: Routine Heartbeat */}
          <div 
            onClick={() => runScenario(
              'Routine Heartbeat Telemetry',
              'heartbeat',
              {
                simHash: 'f4b29a88c3e45990234a991c28b5e903d6118b958c89ff0234ac2b0123ef89aa',
                distanceDeltaKm: 0.1,
                timeDeltaMinutes: 15,
                bleCorroborated: true,
                batteryLevel: 82,
                location: {
                  latitude: 19.0760,
                  longitude: 72.8777,
                  accuracyMeters: 10,
                  addressSummary: 'Bandra Kurla Complex, Mumbai, India'
                }
              }
            )}
            className="p-3 border border-zinc-800/90 rounded-lg hover:border-zinc-700 bg-zinc-950 hover:bg-zinc-850/60 transition-colors cursor-pointer group flex items-start justify-between gap-3"
          >
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-zinc-900 text-zinc-300 border border-zinc-800 flex items-center justify-center shrink-0 mt-0.5">
                <Activity className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs font-medium text-zinc-200 group-hover:text-white">
                  Scenario E: Routine Scheduled Check-in
                </h4>
                <p className="text-[11px] text-zinc-400 mt-0.5">
                  Normal background check-in. Telemetry matches baseline parameters. Risk score ~8–12.
                </p>
              </div>
            </div>
            <Play className="w-4 h-4 text-zinc-400 group-hover:text-zinc-200 shrink-0 mt-2" />
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-zinc-800 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-zinc-800 hover:bg-zinc-750 text-white rounded-lg text-xs font-medium transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
