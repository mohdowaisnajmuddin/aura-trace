import React from 'react';
import { X, Lock, Trash2 } from 'lucide-react';

interface PrivacyModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToSettings: () => void;
}

export const PrivacyModal: React.FC<PrivacyModalProps> = ({ isOpen, onClose, onNavigateToSettings }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div 
        className="bg-zinc-900 border border-zinc-800 rounded-xl max-w-2xl w-full p-6 shadow-2xl relative max-h-[90vh] flex flex-col text-left"
        role="dialog"
        aria-labelledby="privacy-modal-title"
      >
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-zinc-800 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-zinc-950 border border-zinc-800 flex items-center justify-center text-zinc-300">
              <Lock className="w-5 h-5" strokeWidth={1.75} />
            </div>
            <div>
              <h2 id="privacy-modal-title" className="text-base font-medium text-zinc-100 leading-snug tracking-tight">
                Privacy Policy & Telemetry Handling
              </h2>
              <p className="text-xs text-zinc-400">
                Statutory Compliance with India&apos;s Digital Personal Data Protection (DPDP) Act 2023
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-md text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Body */}
        <div className="overflow-y-auto py-4 space-y-4 text-xs text-zinc-300 leading-relaxed pr-1">
          {/* Summary Box */}
          <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-lg text-zinc-300">
            <span className="font-medium text-zinc-100 block mb-1">Our Core Commitment:</span>
            AuraTrace collects the minimum telemetry required to detect phone theft and unauthorized SIM ejection. We do not track browsing history, personal files, app usage, or audio, and we never sell data to commercial brokers.
          </div>

          {/* Section 1: What We Collect */}
          <div>
            <h3 className="font-medium text-zinc-100 text-sm mb-1.5 flex items-center gap-1.5">
              <span>1. Data We Collect & Technical Scope</span>
            </h3>
            <ul className="list-disc pl-5 space-y-1.5 text-zinc-400">
              <li>
                <strong className="text-zinc-200">GPS Geographic Coordinates:</strong> Latitude, longitude, and accuracy radius recorded periodically (heartbeat) or triggered by mobility events to calculate speed and boundary deviations.
              </li>
              <li>
                <strong className="text-zinc-200">Salted SIM Subscription Hash:</strong> A one-way cryptographic SHA-256 hash (with device-specific salt) of the Android `SubscriptionInfo` token. <em className="text-zinc-300">Raw IMSI, IMEI, and ICCID are never collected, logged, or stored in plaintext.</em>
              </li>
              <li>
                <strong className="text-zinc-200">BLE Proximity Signatures:</strong> Ephemeral HMAC-rotating identifier of registered companion devices (smartwatch/keychain) used exclusively to corroborate owner presence and suppress false positives.
              </li>
              <li>
                <strong className="text-zinc-200">Notification Contact Details:</strong> Email address and mobile phone number designated by the owner for incident dispatch.
              </li>
            </ul>
          </div>

          {/* Section 2: Data Retention Window */}
          <div>
            <h3 className="font-medium text-zinc-100 text-sm mb-1.5">
              2. Retention Window (Enforced 90-Day Policy)
            </h3>
            <p className="text-zinc-400">
              In accordance with Section 8(7) of the DPDP Act 2023, telemetry data is retained only for as long as necessary for anti-theft verification:
            </p>
            <div className="mt-2 p-3 bg-zinc-950 border border-zinc-800 rounded-lg">
              <span className="font-mono text-zinc-200 font-medium">90-Day Rolling TTL:</span>
              <span className="ml-2 text-zinc-400">
                All historical location breadcrumbs and routine heartbeat records older than 90 days are automatically purged via scheduled Firestore database cleanup tasks.
              </span>
            </div>
          </div>

          {/* Section 3: Third-Party Processors */}
          <div>
            <h3 className="font-medium text-zinc-100 text-sm mb-1.5">
              3. Named Third-Party Service Providers
            </h3>
            <p className="text-zinc-400">
              To deliver multi-channel emergency alerts during an incident, AuraTrace transmits contact info and incident summaries to named, SOC2-certified sub-processors:
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2">
              <div className="p-2.5 bg-zinc-950 border border-zinc-800 rounded-lg">
                <span className="font-medium text-zinc-200 block">Twilio Inc.</span>
                <span className="text-[11px] text-zinc-400">
                  Processes designated phone number to deliver immediate SMS security dispatch when risk is elevated.
                </span>
              </div>
              <div className="p-2.5 bg-zinc-950 border border-zinc-800 rounded-lg">
                <span className="font-medium text-zinc-200 block">SendGrid (Twilio)</span>
                <span className="text-[11px] text-zinc-400">
                  Processes designated recipient email address to deliver full incident diagnostic reports.
                </span>
              </div>
            </div>
          </div>

          {/* Section 4: Deletion Rights */}
          <div>
            <h3 className="font-medium text-zinc-100 text-sm mb-1.5">
              4. Right to Erasure (One-Click Deletion)
            </h3>
            <p className="text-zinc-400">
              You maintain complete ownership of your data. You may execute an instantaneous, irreversible purge of your device registration, stored locations, and alert history directly through the application settings.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-4 border-t border-zinc-800 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <button
            onClick={() => {
              onClose();
              onNavigateToSettings();
            }}
            className="text-xs font-medium text-red-400 hover:text-red-300 flex items-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Go to One-Click Data Erasure</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 bg-zinc-800 hover:bg-zinc-750 text-zinc-100 rounded-lg text-xs font-medium transition-colors self-end sm:self-auto"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
