import React, { useState } from 'react';
import { 
  Smartphone, 
  Settings, 
  Lock, 
  HelpCircle, 
  Activity, 
  LogOut, 
  ChevronDown,
  Layout
} from 'lucide-react';
import { DeviceStatus, AuthUser } from '../types';

interface NavbarProps {
  currentTab: 'landing' | 'dashboard' | 'settings' | 'faq';
  setCurrentTab: (tab: 'landing' | 'dashboard' | 'settings' | 'faq') => void;
  openPrivacyModal: () => void;
  openSimulator: () => void;
  openGoogleAuth: (mode?: 'signin' | 'signup') => void;
  currentUser: AuthUser | null;
  onSignOut: () => void;
  deviceStatus: DeviceStatus;
  alertsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  openPrivacyModal,
  openSimulator,
  openGoogleAuth,
  currentUser,
  onSignOut,
  deviceStatus
}) => {
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);

  return (
    <header className="border-b border-zinc-900 bg-zinc-950/95 sticky top-0 z-30 backdrop-blur-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand & Live Connection Indicator */}
          <div className="flex items-center gap-3 sm:gap-4">
            <div 
              className="flex items-center gap-2.5 cursor-pointer"
              onClick={() => setCurrentTab('landing')}
              id="brand-header"
              title="Return to AuraTrace Overview"
            >
              <div className="w-8 h-8 rounded-lg bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-200">
                <Smartphone className="w-4 h-4" strokeWidth={1.75} />
              </div>
              <div className="flex items-center gap-2">
                <span className="font-medium text-base text-zinc-100 tracking-tight">AuraTrace</span>
                <span className="text-[11px] font-mono text-zinc-500 border border-zinc-800 px-1.5 py-0.5 rounded">v2.0</span>
              </div>
            </div>

            {/* Real-Time Firestore Sync Pill */}
            <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-xs text-zinc-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-medium text-zinc-300">Firestore Real-Time Sync</span>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="flex items-center gap-1 sm:gap-1.5">
            <button
              id="nav-tab-landing"
              onClick={() => setCurrentTab('landing')}
              className={`px-2.5 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-colors flex items-center gap-1.5 ${
                currentTab === 'landing'
                  ? 'bg-zinc-850 text-white border border-zinc-800'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
              }`}
            >
              <Layout className="w-3.5 h-3.5 sm:w-4 sm:h-4" strokeWidth={1.75} />
              <span>Overview</span>
            </button>

            <button
              id="nav-tab-dashboard"
              onClick={() => setCurrentTab('dashboard')}
              className={`px-2.5 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-colors flex items-center gap-1.5 ${
                currentTab === 'dashboard'
                  ? 'bg-zinc-900 text-white border border-zinc-800'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5 sm:w-4 sm:h-4" strokeWidth={1.75} />
              <span>Dashboard</span>
              {deviceStatus === 'high_risk' && (
                <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
              )}
            </button>

            <button
              id="nav-tab-settings"
              onClick={() => setCurrentTab('settings')}
              className={`px-2.5 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-colors hidden sm:flex items-center gap-1.5 ${
                currentTab === 'settings'
                  ? 'bg-zinc-900 text-white border border-zinc-800'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
              }`}
            >
              <Settings className="w-3.5 h-3.5 sm:w-4 sm:h-4" strokeWidth={1.75} />
              <span>Settings</span>
            </button>

            <button
              id="nav-tab-faq"
              onClick={() => setCurrentTab('faq')}
              className={`px-2.5 py-1.5 rounded-md text-xs sm:text-sm font-medium transition-colors hidden md:flex items-center gap-1.5 ${
                currentTab === 'faq'
                  ? 'bg-zinc-900 text-white border border-zinc-800'
                  : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900'
              }`}
            >
              <HelpCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4" strokeWidth={1.75} />
              <span>FAQ</span>
            </button>

            <button
              id="nav-privacy-btn"
              onClick={openPrivacyModal}
              title="Privacy Policy & DPDP Compliance"
              className="px-2 py-1.5 rounded-md text-xs font-medium text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900 transition-colors hidden xl:flex items-center gap-1"
            >
              <Lock className="w-3.5 h-3.5" strokeWidth={1.75} />
              <span>DPDP</span>
            </button>

            {/* Quick Simulator Launcher */}
            <button
              id="open-simulator-btn"
              onClick={openSimulator}
              className="px-2.5 py-1.5 rounded-md text-xs font-medium border border-zinc-800 bg-zinc-900 text-zinc-300 hover:bg-zinc-850 hover:text-white transition-colors flex items-center gap-1.5"
            >
              <Activity className="w-3.5 h-3.5 text-zinc-400" />
              <span className="hidden sm:inline">Simulate</span>
            </button>

            {/* Google Authentication Status / Sign In Button */}
            <div className="ml-1 sm:ml-2 relative">
              {currentUser ? (
                <div className="relative">
                  <button
                    onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                    className="flex items-center gap-2 p-1 pl-2 rounded-full border border-zinc-800 hover:border-zinc-700 bg-zinc-900 hover:bg-zinc-850 transition-all text-left"
                    id="user-menu-button"
                  >
                    <div className="w-6 h-6 rounded-full bg-zinc-800 text-zinc-200 border border-zinc-700 text-[11px] font-medium flex items-center justify-center">
                      {currentUser.displayName.slice(0, 2).toUpperCase()}
                    </div>
                    <span className="text-xs font-medium text-zinc-300 hidden md:inline max-w-[100px] truncate">
                      {currentUser.displayName}
                    </span>
                    <ChevronDown className="w-3.5 h-3.5 text-zinc-500 mr-1" />
                  </button>

                  {/* Dropdown Menu */}
                  {isUserMenuOpen && (
                    <div 
                      className="absolute right-0 mt-2 w-64 bg-zinc-900 border border-zinc-800 rounded-xl shadow-2xl py-2 z-40 text-xs animate-in fade-in"
                      onClick={() => setIsUserMenuOpen(false)}
                    >
                      <div className="px-3.5 py-2 border-b border-zinc-800">
                        <div className="font-medium text-zinc-100 truncate">
                          {currentUser.displayName}
                        </div>
                        <div className="text-zinc-400 text-[11px] truncate">
                          {currentUser.email}
                        </div>
                        <div className="mt-1.5 flex items-center gap-1.5 text-[10px] text-emerald-400 font-mono">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                          <span>Google Authenticated</span>
                        </div>
                      </div>

                      <div className="py-1">
                        <button
                          onClick={() => setCurrentTab('settings')}
                          className="w-full text-left px-3.5 py-2 hover:bg-zinc-850 text-zinc-300 hover:text-white flex items-center gap-2"
                        >
                          <Settings className="w-3.5 h-3.5 text-zinc-500" />
                          <span>Security & Alerts Settings</span>
                        </button>
                        <button
                          onClick={openPrivacyModal}
                          className="w-full text-left px-3.5 py-2 hover:bg-zinc-850 text-zinc-300 hover:text-white flex items-center gap-2"
                        >
                          <Lock className="w-3.5 h-3.5 text-zinc-500" />
                          <span>Statutory DPDP Rights</span>
                        </button>
                      </div>

                      <div className="border-t border-zinc-800 pt-1">
                        <button
                          onClick={onSignOut}
                          className="w-full text-left px-3.5 py-2 hover:bg-red-950/40 text-red-400 flex items-center gap-2 font-medium"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          <span>Sign out</span>
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <button
                  onClick={() => openGoogleAuth('signin')}
                  className="px-3 py-1.5 rounded-md text-xs font-medium border border-zinc-800 hover:border-zinc-700 bg-zinc-900 hover:bg-zinc-850 text-zinc-200 hover:text-white transition-colors flex items-center gap-1.5"
                  id="navbar-google-signin"
                >
                  <svg className="w-3.5 h-3.5 shrink-0" viewBox="0 0 24 24">
                    <path
                      fill="#4285F4"
                      d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.8-2.4 3.65v3.03h3.88c2.27-2.09 3.665-5.17 3.665-9.12z"
                    />
                    <path
                      fill="#34A853"
                      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.03c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.13C3.27 21.42 7.35 24 12 24z"
                    />
                    <path
                      fill="#FBBC05"
                      d="M5.28 14.29c-.25-.72-.38-1.49-.38-2.29s.13-1.57.38-2.29V6.58H1.25C.45 8.18 0 9.99 0 12s.45 3.82 1.25 5.42l4.03-3.13z"
                    />
                    <path
                      fill="#EA4335"
                      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.27 2.58 1.25 6.58l4.03 3.13c.95-2.83 3.6-4.96 6.72-4.96z"
                    />
                  </svg>
                  <span className="hidden sm:inline">Sign in with Google</span>
                  <span className="sm:hidden">Sign in</span>
                </button>
              )}
            </div>
          </nav>
        </div>
      </div>
    </header>
  );
};
