import { Device, DeviceEvent, AlertRecord, UserSettings, LocationData } from '../types';
import { evaluateDeviceRisk, RISK_MODEL_METADATA } from './riskEngine';

const STORAGE_KEY_PREFIX = 'auratrace_v3_';

const DEFAULT_SETTINGS: UserSettings = {
  deviceNickname: 'Google Pixel 8 (Primary)',
  smsAlertsEnabled: true,
  emailAlertsEnabled: true,
  recipientPhone: '+91 98765 43210',
  recipientEmail: 'owner@auratrace.dev',
  warningThreshold: 35,
  criticalThreshold: 70,
  rateLimitMinutes: 15,
  dataRetentionDays: 90
};

const INITIAL_DEVICE: Device = {
  id: 'dev-pixel8-in',
  ownerUid: 'usr_device_owner',
  nickname: 'Google Pixel 8 (Primary)',
  deviceModel: 'Google Pixel 8 (Tensor G3)',
  osVersion: 'Android 14 (API 34)',
  status: 'secure',
  riskScore: 12,
  lastCheckIn: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
  lastKnownSimHash: 'f4b29a88c3e45990234a991c28b5e903d6118b958c89ff0234ac2b0123ef89aa', // Salted SHA-256 of SubscriptionId + CarrierPrivileges
  lastKnownLocation: {
    latitude: 19.0760,
    longitude: 72.8777,
    accuracyMeters: 14,
    addressSummary: 'Bandra Kurla Complex, Mumbai, MH, India'
  },
  authToken: 'at_live_sec_7894109284210'
};

const INITIAL_EVENTS: DeviceEvent[] = [
  {
    id: 'evt-3091',
    deviceId: 'dev-pixel8-in',
    type: 'heartbeat',
    timestamp: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
    riskScore: 12,
    triggeredFactors: [
      {
        factorKey: 'ble_corroboration',
        label: 'Trusted BLE Proximity Corroboration',
        impactScore: -22,
        description: 'Pixel Watch 2 (paired owner wearable) detected via HMAC-authenticated BLE broadcast.'
      }
    ],
    payload: {
      location: {
        latitude: 19.0760,
        longitude: 72.8777,
        accuracyMeters: 14,
        addressSummary: 'Bandra Kurla Complex, Mumbai, MH, India'
      },
      simHash: 'f4b29a88c3e45990234a991c28b5e903d6118b958c89ff0234ac2b0123ef89aa',
      batteryLevel: 84,
      networkType: '5G SA (Jio)',
      carrierName: 'Jio True5G',
      bleCorroborated: true
    }
  },
  {
    id: 'evt-3088',
    deviceId: 'dev-pixel8-in',
    type: 'heartbeat',
    timestamp: new Date(Date.now() - 38 * 60 * 1000).toISOString(),
    riskScore: 14,
    triggeredFactors: [],
    payload: {
      location: {
        latitude: 19.0722,
        longitude: 72.8732,
        accuracyMeters: 18,
        addressSummary: 'BKC Central Avenue, Mumbai, MH, India'
      },
      simHash: 'f4b29a88c3e45990234a991c28b5e903d6118b958c89ff0234ac2b0123ef89aa',
      batteryLevel: 88,
      networkType: '5G SA (Jio)',
      carrierName: 'Jio True5G',
      bleCorroborated: true
    }
  },
  {
    id: 'evt-3075',
    deviceId: 'dev-pixel8-in',
    type: 'ble_sighting',
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    riskScore: 8,
    triggeredFactors: [
      {
        factorKey: 'ble_corroboration',
        label: 'Companion BLE Beacon Detected',
        impactScore: -22,
        description: 'HMAC-rotating beacon matching owner keychain sighted with RSSI -58 dBm.'
      }
    ],
    payload: {
      location: {
        latitude: 19.0601,
        longitude: 72.8362,
        accuracyMeters: 25,
        addressSummary: 'Khar West, Mumbai, MH, India'
      },
      bleBeaconId: 'aura_hmac_89af3b',
      bleCorroborated: true,
      batteryLevel: 92
    }
  }
];

const INITIAL_ALERTS: AlertRecord[] = [
  {
    id: 'alt-102',
    deviceId: 'dev-pixel8-in',
    eventId: 'evt-3075',
    channel: 'email',
    severity: 'warning',
    sentAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    recipient: 'owner@auratrace.dev',
    summary: 'System health check completed. Baseline security telemetry registered for Google Pixel 8.',
    deliveryStatus: 'delivered'
  }
];

// In-Memory state with local-storage fallback to simulate Firestore collections
class FirestoreSimulationStore {
  private device: Device;
  private events: DeviceEvent[];
  private alerts: AlertRecord[];
  private settings: UserSettings;
  private lastAlertTimestamp: number = 0;

  // Listeners for onSnapshot pattern
  private deviceSubscribers = new Set<(device: Device) => void>();
  private eventsSubscribers = new Set<(events: DeviceEvent[]) => void>();
  private alertsSubscribers = new Set<(alerts: AlertRecord[]) => void>();
  private settingsSubscribers = new Set<(settings: UserSettings) => void>();

  constructor() {
    this.device = this.load('device', INITIAL_DEVICE);
    this.events = this.load('events', INITIAL_EVENTS);
    this.alerts = this.load('alerts', INITIAL_ALERTS);
    this.settings = this.load('settings', DEFAULT_SETTINGS);
  }

  private load<T>(key: string, fallback: T): T {
    try {
      const item = localStorage.getItem(STORAGE_KEY_PREFIX + key);
      if (item) return JSON.parse(item);
    } catch {
      // ignore
    }
    return fallback;
  }

  private save(key: string, data: unknown): void {
    try {
      localStorage.setItem(STORAGE_KEY_PREFIX + key, JSON.stringify(data));
    } catch {
      // ignore
    }
  }

  // Subscriptions (Firestore onSnapshot equivalent)
  public onSnapshotDevice(deviceId: string, callback: (device: Device) => void): () => void {
    callback(this.device);
    this.deviceSubscribers.add(callback);
    return () => {
      this.deviceSubscribers.delete(callback);
    };
  }

  public onSnapshotEvents(deviceId: string, callback: (events: DeviceEvent[]) => void): () => void {
    callback([...this.events]);
    this.eventsSubscribers.add(callback);
    return () => {
      this.eventsSubscribers.delete(callback);
    };
  }

  public onSnapshotAlerts(deviceId: string, callback: (alerts: AlertRecord[]) => void): () => void {
    callback([...this.alerts]);
    this.alertsSubscribers.add(callback);
    return () => {
      this.alertsSubscribers.delete(callback);
    };
  }

  public onSnapshotSettings(callback: (settings: UserSettings) => void): () => void {
    callback(this.settings);
    this.settingsSubscribers.add(callback);
    return () => {
      this.settingsSubscribers.delete(callback);
    };
  }

  public getSettings(): UserSettings {
    return this.settings;
  }

  public updateSettings(updates: Partial<UserSettings>): UserSettings {
    this.settings = { ...this.settings, ...updates };
    if (updates.deviceNickname && updates.deviceNickname !== this.device.nickname) {
      this.device.nickname = updates.deviceNickname;
      this.notifyDevice();
    }
    this.save('settings', this.settings);
    this.settingsSubscribers.forEach((cb) => cb(this.settings));
    return this.settings;
  }

  /**
   * Simulates POST /api/events
   * Consumes telemetry event, evaluates ML risk model, updates device,
   * generates alerts if thresholds breached, and triggers real-time listeners.
   */
  public pushEvent(input: {
    type: 'sim_change' | 'location_jump' | 'ble_sighting' | 'heartbeat';
    payload: DeviceEvent['payload'];
    timestamp?: string;
  }): { event: DeviceEvent; riskScore: number; status: string } {
    const timestamp = input.timestamp || new Date().toISOString();

    // 1. Run ML Risk Engine
    const scoring = evaluateDeviceRisk(
      {
        type: input.type,
        timestamp,
        payload: input.payload
      },
      this.device
    );

    // 2. Form Event Record
    const eventId = `evt-${Date.now().toString().slice(-6)}`;
    const newEvent: DeviceEvent = {
      id: eventId,
      deviceId: this.device.id,
      type: input.type,
      timestamp,
      riskScore: scoring.riskScore,
      triggeredFactors: scoring.factors,
      payload: input.payload
    };

    // 3. Update Device state in Firestore
    this.device.lastCheckIn = timestamp;
    this.device.riskScore = scoring.riskScore;
    this.device.status = scoring.status;

    if (input.payload.location) {
      this.device.lastKnownLocation = input.payload.location;
    }
    if (input.payload.simHash) {
      this.device.lastKnownSimHash = input.payload.simHash;
    }

    // 4. Evaluate Alert Thresholds & Dispatch Multi-Channel Alerts
    const now = Date.now();
    const rateLimitMs = (this.settings.rateLimitMinutes || 15) * 60 * 1000;
    const canDispatch = now - this.lastAlertTimestamp >= rateLimitMs || scoring.riskScore >= this.settings.criticalThreshold;

    if (scoring.riskScore >= this.settings.warningThreshold && canDispatch) {
      const severity = scoring.riskScore >= this.settings.criticalThreshold ? 'critical' : 'warning';
      
      let summary = '';
      if (input.type === 'sim_change') {
        summary = `AuraTrace Alert: SIM state mutation detected on "${this.device.nickname}". Salted hash mismatch. Risk Score: ${scoring.riskScore}/100.`;
      } else if (input.type === 'location_jump') {
        summary = `AuraTrace Alert: Anomalous location jump detected on "${this.device.nickname}". Distance change: ${input.payload.distanceDeltaKm ?? 'unknown'} km. Risk Score: ${scoring.riskScore}/100.`;
      } else {
        summary = `AuraTrace Alert: Elevated security risk (${scoring.riskScore}/100) registered on "${this.device.nickname}".`;
      }

      // Dispatch to configured channels
      if (this.settings.smsAlertsEnabled && this.settings.recipientPhone) {
        const smsAlert: AlertRecord = {
          id: `alt-sms-${Date.now().toString().slice(-5)}`,
          deviceId: this.device.id,
          eventId: newEvent.id,
          channel: 'sms',
          severity,
          sentAt: timestamp,
          recipient: this.settings.recipientPhone,
          summary: `[SMS via Twilio] ${summary}`,
          deliveryStatus: 'delivered'
        };
        this.alerts.unshift(smsAlert);
        newEvent.alertDispatched = { channel: 'sms', severity, alertId: smsAlert.id };
      }

      if (this.settings.emailAlertsEnabled && this.settings.recipientEmail) {
        const emailAlert: AlertRecord = {
          id: `alt-eml-${Date.now().toString().slice(-5)}`,
          deviceId: this.device.id,
          eventId: newEvent.id,
          channel: 'email',
          severity,
          sentAt: timestamp,
          recipient: this.settings.recipientEmail,
          summary: `[Email via SendGrid] ${summary}`,
          deliveryStatus: 'delivered'
        };
        this.alerts.unshift(emailAlert);
        newEvent.alertDispatched = { channel: 'email', severity, alertId: emailAlert.id };
      }

      this.lastAlertTimestamp = now;
      this.save('alerts', this.alerts);
      this.notifyAlerts();
    }

    // 5. Append to events collection (capped to 60 items)
    this.events.unshift(newEvent);
    if (this.events.length > 60) {
      this.events = this.events.slice(0, 60);
    }

    // 6. Save & Notify all active onSnapshot listeners immediately
    this.save('device', this.device);
    this.save('events', this.events);
    this.notifyDevice();
    this.notifyEvents();

    return {
      event: newEvent,
      riskScore: scoring.riskScore,
      status: scoring.status
    };
  }

  /**
   * One-click "Delete My Data" action per PRD Section 7 & DPDP Act 2023.
   * Completely purges all location history, events, and alerts.
   */
  public deleteMyData(): { success: boolean; purgedRecords: number } {
    const totalPurged = this.events.length + this.alerts.length + 1;
    
    // Reset to pristine empty state
    this.events = [];
    this.alerts = [];
    this.device = {
      ...INITIAL_DEVICE,
      riskScore: 0,
      status: 'secure',
      lastCheckIn: new Date().toISOString(),
      lastKnownSimHash: 'deleted_hash_salt_purged',
      lastKnownLocation: {
        latitude: 0,
        longitude: 0,
        accuracyMeters: 0,
        addressSummary: 'Data permanently purged upon owner request'
      }
    };

    localStorage.removeItem(STORAGE_KEY_PREFIX + 'device');
    localStorage.removeItem(STORAGE_KEY_PREFIX + 'events');
    localStorage.removeItem(STORAGE_KEY_PREFIX + 'alerts');

    this.notifyDevice();
    this.notifyEvents();
    this.notifyAlerts();

    return {
      success: true,
      purgedRecords: totalPurged
    };
  }

  /**
   * Reset to initial sample data for demonstration/testing
   */
  public resetSampleData(): void {
    this.device = { ...INITIAL_DEVICE };
    this.events = [...INITIAL_EVENTS];
    this.alerts = [...INITIAL_ALERTS];
    this.settings = { ...DEFAULT_SETTINGS };

    this.save('device', this.device);
    this.save('events', this.events);
    this.save('alerts', this.alerts);
    this.save('settings', this.settings);

    this.notifyDevice();
    this.notifyEvents();
    this.notifyAlerts();
    this.settingsSubscribers.forEach((cb) => cb(this.settings));
  }

  private notifyDevice() {
    this.deviceSubscribers.forEach((cb) => cb({ ...this.device }));
  }

  private notifyEvents() {
    this.eventsSubscribers.forEach((cb) => cb([...this.events]));
  }

  private notifyAlerts() {
    this.alertsSubscribers.forEach((cb) => cb([...this.alerts]));
  }
}

export const firestoreStore = new FirestoreSimulationStore();
