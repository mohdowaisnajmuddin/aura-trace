export type DeviceStatus = 'secure' | 'elevated_risk' | 'high_risk';

export type EventType = 'sim_change' | 'location_jump' | 'ble_sighting' | 'heartbeat';

export type AlertChannel = 'sms' | 'email';

export type AlertSeverity = 'warning' | 'critical';

export interface LocationData {
  latitude: number;
  longitude: number;
  accuracyMeters: number;
  addressSummary: string;
}

export interface Device {
  id: string;
  ownerUid: string;
  nickname: string;
  deviceModel: string;
  osVersion: string;
  status: DeviceStatus;
  riskScore: number;
  lastCheckIn: string; // ISO 8601 string
  lastKnownSimHash: string; // Salted SHA-256 of subscription info
  lastKnownLocation: LocationData;
  authToken: string;
}

export interface RiskFactor {
  factorKey: 'sim_change' | 'location_jump' | 'time_anomaly' | 'checkin_delay' | 'ble_corroboration';
  label: string;
  impactScore: number; // e.g. +45, -20
  description: string;
}

export interface DeviceEvent {
  id: string;
  deviceId: string;
  type: EventType;
  timestamp: string; // ISO 8601 string
  riskScore: number;
  triggeredFactors: RiskFactor[];
  payload: {
    location?: LocationData;
    simHash?: string;
    previousSimHash?: string;
    simStateChangeReason?: string;
    distanceDeltaKm?: number;
    timeDeltaMinutes?: number;
    bleBeaconId?: string;
    bleCorroborated?: boolean;
    batteryLevel?: number;
    networkType?: string;
    carrierName?: string;
  };
  alertDispatched?: {
    channel: AlertChannel;
    severity: AlertSeverity;
    alertId: string;
  };
}

export interface AlertRecord {
  id: string;
  deviceId: string;
  eventId: string;
  channel: AlertChannel;
  severity: AlertSeverity;
  sentAt: string;
  recipient: string;
  summary: string;
  deliveryStatus: 'delivered' | 'dispatched' | 'simulated';
}

export interface RiskModelMetadata {
  version: string;
  trainedAt: string;
  modelType: string;
  features: string[];
  precision: number;
  recall: number;
  sampleSize: number;
  datasetNote: string;
  formulaDescription: string;
}

export interface UserSettings {
  deviceNickname: string;
  smsAlertsEnabled: boolean;
  emailAlertsEnabled: boolean;
  recipientPhone: string;
  recipientEmail: string;
  warningThreshold: number; // default: 35
  criticalThreshold: number; // default: 70
  rateLimitMinutes: number; // default: 15
  dataRetentionDays: number; // default: 90
}

export interface AuthUser {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  provider: 'google';
  createdAt: string;
}
